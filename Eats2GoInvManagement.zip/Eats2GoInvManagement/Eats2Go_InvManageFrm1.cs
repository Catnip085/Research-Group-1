﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eats2GoInvManagement
{
    public partial class Eats2Go_InvManageFrm1 : MetroForm
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader rdr;

        public Eats2Go_InvManageFrm1()
        {
            InitializeComponent();
        }

        private void SetConnection()
        {
            con = new SqlConnection(
                @"Data Source = SHRINE\SQLEXPRESS; 
                Initial Catalog = Eats2GoInvManager_DBDEMO; 
                Integrated Security = True;");
        }

        private void ClearAll()
        {
            txt_invID.Clear();
            txt_invName.Clear();
            txt_unitPrice.Clear();
            txt_stockQuan.Clear();
            txt_invValue.Clear();
            txt_avgDailyUsage.Clear();
            txt_leadTime.Clear();
            txt_reorderPoint.Clear();
            txt_reorderQuan.Clear();
            cmbo_invCat.SelectedIndex = -1;
            txt_unitType.Clear();
            btn_invAdd.Enabled = true;
            btn_invSave.Enabled = false; 
        }

        private void LoadInventory()
        {
            data_Inv.Rows.Clear();
            con.Open();
            cmd = new SqlCommand(@"SELECT invID, invName, unitPrice, stockQuan, unitPrice * stockQuan AS 'Inventory Value', avgDailyUsage, leadTime, avgDailyUsage * leadTime AS 'Reorder Point', reorderQuan, invCat, unitType FROM INVENTORY;", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                data_Inv.Rows.Add(rdr[0].ToString(), rdr[1].ToString(),
                    rdr[2].ToString(), rdr[3].ToString(),
                    rdr[4].ToString(), rdr[5].ToString(), 
                    rdr[6].ToString(), rdr[7].ToString(), 
                    rdr[8].ToString(), rdr[9].ToString(),
                    rdr[10].ToString());
            }
            con.Close();
        }

        private void LoadInventory(string searchText = "", string category = "")
        {
            data_Inv.Rows.Clear();
            con.Open();
            StringBuilder query = new StringBuilder(@"SELECT invID, invName, unitPrice, stockQuan, unitPrice * stockQuan AS 'Inventory Value', avgDailyUsage, 
        leadTime, avgDailyUsage * leadTime AS 'Reorder Point', reorderQuan, invCat, unitType FROM INVENTORY WHERE 1=1");

            if (!string.IsNullOrEmpty(searchText))
            {
                query.Append(@" AND (invID LIKE '%" + searchText
                    + "%' OR invName LIKE '%" + searchText
                    + "%' OR unitPrice LIKE '%" + searchText
                    + "%' OR unitPrice * stockQuan LIKE '%" + searchText
                    + "%' OR avgDailyUsage LIKE '%" + searchText
                    + "%' OR leadTime LIKE '%" + searchText
                    + "%' OR avgDailyUsage * leadTime LIKE '%" + searchText
                    + "%' OR invCat LIKE '%" + searchText
                    + "%' OR unitType LIKE '%" + searchText
                    + "%' OR reorderQuan LIKE '%" + searchText + "%')");
            }

            if (!string.IsNullOrEmpty(category))
            {
                query.Append(" AND invCat = '" + category + "'");
            }

            query.Append(";");
            cmd = new SqlCommand(query.ToString(), con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                data_Inv.Rows.Add(rdr[0].ToString(), rdr[1].ToString(),
                     rdr[2].ToString(), rdr[3].ToString(),
                     rdr[4].ToString(), rdr[5].ToString(),
                     rdr[6].ToString(), rdr[7].ToString(),
                     rdr[8].ToString(), rdr[9].ToString(),
                     rdr[10].ToString());
            }
            con.Close();
        }
        private void Eats2Go_InvManageFrm1_Load(object sender, EventArgs e)
        {
            SetConnection();
            LoadInventory();
            LoadCat();
            cmbo_invCat.SelectedIndex = -1;
            cmbo_catSearch.SelectedIndex = -1;
        }

        private void btn_invAdd_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand(@"INSERT INTO 
            INVENTORY (invName, unitPrice, stockQuan, avgDailyUsage, leadTime, reorderQuan, invCat, unitType)
            VALUES ('" + txt_invName.Text + "','" + txt_unitPrice.Text + "','" + txt_stockQuan.Text + "','" + txt_avgDailyUsage.Text + "','" + txt_leadTime.Text + "','" + txt_reorderQuan.Text + "','" + cmbo_invCat.Text + "','" + txt_unitType.Text + "');", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Item Added Successfully", "Success");
            LoadInventory();
            ClearAll();
        }

        private void data_Inv_SelectionChanged(object sender, EventArgs e)
        {
            if (data_Inv.SelectedRows.Count > 0)
            {
                DataGridViewRow selected = data_Inv.SelectedRows[0];
                txt_invID.Text = selected.Cells[0].Value.ToString();
                txt_invName.Text = selected.Cells[1].Value.ToString();
                txt_unitPrice.Text = selected.Cells[2].Value.ToString();
                txt_stockQuan.Text = selected.Cells[3].Value.ToString();
                txt_invValue.Text = selected.Cells[4].Value.ToString();
                txt_avgDailyUsage.Text = selected.Cells[5].Value.ToString();
                txt_leadTime.Text = selected.Cells[6].Value.ToString();
                txt_reorderPoint.Text = selected.Cells[7].Value.ToString();
                txt_reorderQuan.Text = selected.Cells[8].Value.ToString();
                cmbo_invCat.Text = selected.Cells[9].Value.ToString();
                txt_unitType.Text = selected.Cells[10].Value.ToString();
                btn_invSave.Enabled = true;
                btn_invAdd.Enabled = false;
            }
        }

        private void btn_invSave_Click(object sender, EventArgs e)
        {
            if (data_Inv.SelectedRows.Count > 0)
            {
                con.Open();
                cmd = new SqlCommand("UPDATE INVENTORY SET invName = '"
                    + txt_invName.Text
                    + "', unitPrice = '" + txt_unitPrice.Text
                    + "', stockQuan = '" + txt_stockQuan.Text
                    + "', avgDailyUsage = '" + txt_avgDailyUsage.Text
                    + "', leadTime = '" + txt_leadTime.Text
                    + "', reorderQuan = '" + txt_reorderQuan.Text
                    + "', invCat = '" + cmbo_invCat.Text
                    + "', unitType = '" + txt_unitType.Text
                    + "' WHERE invID = '" + txt_invID.Text + "';", con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Item Updated", "Success");
                LoadInventory();
                ClearAll();
            }
        }

        private void btn_invClear_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            if (data_Inv.SelectedRows.Count > 0)
            {
                con.Open();
                cmd = new SqlCommand(@"DELETE FROM INVENTORY
                    WHERE invID = '" + txt_invID.Text + "';", con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Item Record Removed Successfully.", "Success");
                LoadInventory();
                ClearAll();
            }
        }

        private void btn_invLoad_Click(object sender, EventArgs e)
        {
            LoadInventory();
        }

        public List<string> Categories = new List<string>() { "Produce", "Dairy", "Meat and Poultry", "Grains and Cereals", "Canned and Jarred Goods", "Beverages", "Condiments and Spices", "Frozen Foods", "Snacks and Sweets"};
        public List<string> Categories2 = new List<string>() { "Produce", "Dairy", "Meat and Poultry", "Grains and Cereals", "Canned and Jarred Goods", "Beverages", "Condiments and Spices", "Frozen Foods", "Snacks and Sweets" };
        public void LoadCat()
        {
            cmbo_catSearch.DataSource = Categories2;
            cmbo_invCat.DataSource = Categories;
        }

        private void btn_invSearch_Click(object sender, EventArgs e)
        {
            string searchText = txt_invSearch.Text;
            string category = cmbo_catSearch.SelectedItem != null ? cmbo_catSearch.SelectedItem.ToString() : "";
            LoadInventory(searchText, category);
        }

        private void btn_catClear_Click(object sender, EventArgs e)
        {
            cmbo_catSearch.SelectedIndex = -1;
        }

        private void data_Inv_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < data_Inv.Rows.Count)
            {
                DataGridViewRow row = data_Inv.Rows[e.RowIndex];
                int targetColumnIndex = 3;
                int comparisonColumnIndex = 7;

                DataGridViewCell targetCell = row.Cells[targetColumnIndex];
                DataGridViewCell comparisonCell = row.Cells[comparisonColumnIndex];

                if (targetCell.Value != null && comparisonCell.Value != null &&
                    double.TryParse(targetCell.Value.ToString(), out double targetValue) &&
                    double.TryParse(comparisonCell.Value.ToString(), out double comparisonValue))
                {
                    if (targetValue <= comparisonValue)
                    {
                        row.DefaultCellStyle.BackColor = Color.FromArgb(240, 128, 128);
                        row.DefaultCellStyle.ForeColor = Color.Black;
                    }
                    else if (targetValue < comparisonValue * 1.25)
                    {
                        row.DefaultCellStyle.BackColor = Color.FromArgb(255, 182, 193);
                        row.DefaultCellStyle.ForeColor = Color.Black;
                    }
                    else if (targetValue < comparisonValue * 1.5)
                    {
                        row.DefaultCellStyle.BackColor = Color.FromArgb(255, 218, 185);
                        row.DefaultCellStyle.ForeColor = Color.Black;
                    }
                    else
                    {
                        row.DefaultCellStyle.BackColor = data_Inv.DefaultCellStyle.BackColor;
                        row.DefaultCellStyle.ForeColor = data_Inv.DefaultCellStyle.ForeColor;
                    }
                }
                else
                {
                    row.DefaultCellStyle.BackColor = data_Inv.DefaultCellStyle.BackColor;
                    row.DefaultCellStyle.ForeColor = data_Inv.DefaultCellStyle.ForeColor;
                }
            }
        }
    }
}
