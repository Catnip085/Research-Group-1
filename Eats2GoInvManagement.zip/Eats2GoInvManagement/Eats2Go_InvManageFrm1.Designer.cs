﻿namespace Eats2GoInvManagement
{
    partial class Eats2Go_InvManageFrm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.data_Inv = new MetroFramework.Controls.MetroGrid();
            this.invID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockQuan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.avgDailyUsage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.leadTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reorderPoint = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reorderQuan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invCat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmbo_catSearch = new MetroFramework.Controls.MetroComboBox();
            this.txt_invSearch = new MetroFramework.Controls.MetroTextBox();
            this.btn_invSearch = new MetroFramework.Controls.MetroButton();
            this.btn_invLoad = new MetroFramework.Controls.MetroButton();
            this.txt_invID = new MetroFramework.Controls.MetroTextBox();
            this.btn_invAdd = new MetroFramework.Controls.MetroButton();
            this.btn_invSave = new MetroFramework.Controls.MetroButton();
            this.btn_invClear = new MetroFramework.Controls.MetroButton();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.txt_invName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.txt_unitPrice = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.txt_stockQuan = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.txt_invValue = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.txt_reorderQuan = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.txt_reorderPoint = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.txt_leadTime = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.txt_avgDailyUsage = new MetroFramework.Controls.MetroTextBox();
            this.cmbo_invCat = new MetroFramework.Controls.MetroComboBox();
            this.btn_Remove = new MetroFramework.Controls.MetroButton();
            this.btn_catClear = new MetroFramework.Controls.MetroButton();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.txt_unitType = new MetroFramework.Controls.MetroTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.data_Inv)).BeginInit();
            this.SuspendLayout();
            // 
            // data_Inv
            // 
            this.data_Inv.AllowUserToAddRows = false;
            this.data_Inv.AllowUserToDeleteRows = false;
            this.data_Inv.AllowUserToResizeRows = false;
            this.data_Inv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.data_Inv.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.data_Inv.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.data_Inv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.data_Inv.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.data_Inv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.data_Inv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data_Inv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.invID,
            this.invName,
            this.unitPrice,
            this.stockQuan,
            this.invValue,
            this.avgDailyUsage,
            this.leadTime,
            this.reorderPoint,
            this.reorderQuan,
            this.invCat,
            this.unitType});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightGray;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.data_Inv.DefaultCellStyle = dataGridViewCellStyle2;
            this.data_Inv.EnableHeadersVisualStyles = false;
            this.data_Inv.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.data_Inv.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.data_Inv.Location = new System.Drawing.Point(13, 369);
            this.data_Inv.Margin = new System.Windows.Forms.Padding(2);
            this.data_Inv.Name = "data_Inv";
            this.data_Inv.ReadOnly = true;
            this.data_Inv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.data_Inv.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.data_Inv.RowHeadersWidth = 72;
            this.data_Inv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.data_Inv.RowTemplate.Height = 31;
            this.data_Inv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.data_Inv.Size = new System.Drawing.Size(1197, 410);
            this.data_Inv.TabIndex = 45;
            this.data_Inv.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.data_Inv_RowPrePaint);
            this.data_Inv.SelectionChanged += new System.EventHandler(this.data_Inv_SelectionChanged);
            // 
            // invID
            // 
            this.invID.HeaderText = "Inventory ID";
            this.invID.MinimumWidth = 9;
            this.invID.Name = "invID";
            this.invID.ReadOnly = true;
            // 
            // invName
            // 
            this.invName.HeaderText = "Name";
            this.invName.MinimumWidth = 9;
            this.invName.Name = "invName";
            this.invName.ReadOnly = true;
            // 
            // unitPrice
            // 
            this.unitPrice.HeaderText = "Unit Price";
            this.unitPrice.MinimumWidth = 9;
            this.unitPrice.Name = "unitPrice";
            this.unitPrice.ReadOnly = true;
            // 
            // stockQuan
            // 
            this.stockQuan.HeaderText = "Quantity in Stock";
            this.stockQuan.MinimumWidth = 9;
            this.stockQuan.Name = "stockQuan";
            this.stockQuan.ReadOnly = true;
            // 
            // invValue
            // 
            this.invValue.HeaderText = "Inventory Value";
            this.invValue.MinimumWidth = 9;
            this.invValue.Name = "invValue";
            this.invValue.ReadOnly = true;
            // 
            // avgDailyUsage
            // 
            this.avgDailyUsage.HeaderText = "Average Daily Usage";
            this.avgDailyUsage.MinimumWidth = 9;
            this.avgDailyUsage.Name = "avgDailyUsage";
            this.avgDailyUsage.ReadOnly = true;
            // 
            // leadTime
            // 
            this.leadTime.HeaderText = "Reorder Time in Days";
            this.leadTime.MinimumWidth = 9;
            this.leadTime.Name = "leadTime";
            this.leadTime.ReadOnly = true;
            // 
            // reorderPoint
            // 
            this.reorderPoint.HeaderText = "Reorder Point";
            this.reorderPoint.MinimumWidth = 9;
            this.reorderPoint.Name = "reorderPoint";
            this.reorderPoint.ReadOnly = true;
            // 
            // reorderQuan
            // 
            this.reorderQuan.HeaderText = "Quantity in Reorder";
            this.reorderQuan.MinimumWidth = 9;
            this.reorderQuan.Name = "reorderQuan";
            this.reorderQuan.ReadOnly = true;
            // 
            // invCat
            // 
            this.invCat.HeaderText = "Category";
            this.invCat.MinimumWidth = 9;
            this.invCat.Name = "invCat";
            this.invCat.ReadOnly = true;
            // 
            // unitType
            // 
            this.unitType.HeaderText = "Unit Type";
            this.unitType.Name = "unitType";
            this.unitType.ReadOnly = true;
            // 
            // cmbo_catSearch
            // 
            this.cmbo_catSearch.FormattingEnabled = true;
            this.cmbo_catSearch.ItemHeight = 23;
            this.cmbo_catSearch.Location = new System.Drawing.Point(14, 328);
            this.cmbo_catSearch.Margin = new System.Windows.Forms.Padding(2);
            this.cmbo_catSearch.Name = "cmbo_catSearch";
            this.cmbo_catSearch.Size = new System.Drawing.Size(177, 29);
            this.cmbo_catSearch.TabIndex = 46;
            this.cmbo_catSearch.UseSelectable = true;
            // 
            // txt_invSearch
            // 
            // 
            // 
            // 
            this.txt_invSearch.CustomButton.Image = null;
            this.txt_invSearch.CustomButton.Location = new System.Drawing.Point(569, 1);
            this.txt_invSearch.CustomButton.Margin = new System.Windows.Forms.Padding(2);
            this.txt_invSearch.CustomButton.Name = "";
            this.txt_invSearch.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txt_invSearch.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_invSearch.CustomButton.TabIndex = 1;
            this.txt_invSearch.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_invSearch.CustomButton.UseSelectable = true;
            this.txt_invSearch.CustomButton.Visible = false;
            this.txt_invSearch.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txt_invSearch.Lines = new string[0];
            this.txt_invSearch.Location = new System.Drawing.Point(313, 328);
            this.txt_invSearch.Margin = new System.Windows.Forms.Padding(2);
            this.txt_invSearch.MaxLength = 32767;
            this.txt_invSearch.Name = "txt_invSearch";
            this.txt_invSearch.PasswordChar = '\0';
            this.txt_invSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_invSearch.SelectedText = "";
            this.txt_invSearch.SelectionLength = 0;
            this.txt_invSearch.SelectionStart = 0;
            this.txt_invSearch.ShortcutsEnabled = true;
            this.txt_invSearch.Size = new System.Drawing.Size(597, 29);
            this.txt_invSearch.TabIndex = 47;
            this.txt_invSearch.UseSelectable = true;
            this.txt_invSearch.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_invSearch.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btn_invSearch
            // 
            this.btn_invSearch.Location = new System.Drawing.Point(914, 328);
            this.btn_invSearch.Margin = new System.Windows.Forms.Padding(2);
            this.btn_invSearch.Name = "btn_invSearch";
            this.btn_invSearch.Size = new System.Drawing.Size(146, 28);
            this.btn_invSearch.TabIndex = 50;
            this.btn_invSearch.Text = "Search";
            this.btn_invSearch.UseSelectable = true;
            this.btn_invSearch.Click += new System.EventHandler(this.btn_invSearch_Click);
            // 
            // btn_invLoad
            // 
            this.btn_invLoad.Location = new System.Drawing.Point(1064, 328);
            this.btn_invLoad.Margin = new System.Windows.Forms.Padding(2);
            this.btn_invLoad.Name = "btn_invLoad";
            this.btn_invLoad.Size = new System.Drawing.Size(146, 28);
            this.btn_invLoad.TabIndex = 51;
            this.btn_invLoad.Text = "Refresh";
            this.btn_invLoad.UseSelectable = true;
            this.btn_invLoad.Click += new System.EventHandler(this.btn_invLoad_Click);
            // 
            // txt_invID
            // 
            this.txt_invID.BackColor = System.Drawing.Color.LightGray;
            // 
            // 
            // 
            this.txt_invID.CustomButton.Image = null;
            this.txt_invID.CustomButton.Location = new System.Drawing.Point(208, 1);
            this.txt_invID.CustomButton.Margin = new System.Windows.Forms.Padding(2);
            this.txt_invID.CustomButton.Name = "";
            this.txt_invID.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txt_invID.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_invID.CustomButton.TabIndex = 1;
            this.txt_invID.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_invID.CustomButton.UseSelectable = true;
            this.txt_invID.CustomButton.Visible = false;
            this.txt_invID.Enabled = false;
            this.txt_invID.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txt_invID.Lines = new string[0];
            this.txt_invID.Location = new System.Drawing.Point(14, 97);
            this.txt_invID.Margin = new System.Windows.Forms.Padding(2);
            this.txt_invID.MaxLength = 32767;
            this.txt_invID.Name = "txt_invID";
            this.txt_invID.PasswordChar = '\0';
            this.txt_invID.ReadOnly = true;
            this.txt_invID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_invID.SelectedText = "";
            this.txt_invID.SelectionLength = 0;
            this.txt_invID.SelectionStart = 0;
            this.txt_invID.ShortcutsEnabled = true;
            this.txt_invID.Size = new System.Drawing.Size(236, 29);
            this.txt_invID.TabIndex = 53;
            this.txt_invID.UseCustomBackColor = true;
            this.txt_invID.UseSelectable = true;
            this.txt_invID.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_invID.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btn_invAdd
            // 
            this.btn_invAdd.BackColor = System.Drawing.SystemColors.Control;
            this.btn_invAdd.Location = new System.Drawing.Point(14, 286);
            this.btn_invAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btn_invAdd.Name = "btn_invAdd";
            this.btn_invAdd.Size = new System.Drawing.Size(295, 29);
            this.btn_invAdd.TabIndex = 54;
            this.btn_invAdd.Text = "Add";
            this.btn_invAdd.UseSelectable = true;
            this.btn_invAdd.Click += new System.EventHandler(this.btn_invAdd_Click);
            // 
            // btn_invSave
            // 
            this.btn_invSave.Location = new System.Drawing.Point(313, 286);
            this.btn_invSave.Margin = new System.Windows.Forms.Padding(2);
            this.btn_invSave.Name = "btn_invSave";
            this.btn_invSave.Size = new System.Drawing.Size(296, 29);
            this.btn_invSave.TabIndex = 55;
            this.btn_invSave.Text = "Save";
            this.btn_invSave.UseSelectable = true;
            this.btn_invSave.Click += new System.EventHandler(this.btn_invSave_Click);
            // 
            // btn_invClear
            // 
            this.btn_invClear.Location = new System.Drawing.Point(613, 286);
            this.btn_invClear.Margin = new System.Windows.Forms.Padding(2);
            this.btn_invClear.Name = "btn_invClear";
            this.btn_invClear.Size = new System.Drawing.Size(297, 29);
            this.btn_invClear.TabIndex = 56;
            this.btn_invClear.Text = "Clear";
            this.btn_invClear.UseSelectable = true;
            this.btn_invClear.Click += new System.EventHandler(this.btn_invClear_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel2.Location = new System.Drawing.Point(14, 80);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(18, 15);
            this.metroLabel2.TabIndex = 58;
            this.metroLabel2.Text = "ID";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel3.Location = new System.Drawing.Point(14, 133);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(38, 15);
            this.metroLabel3.TabIndex = 62;
            this.metroLabel3.Text = "Name";
            // 
            // txt_invName
            // 
            // 
            // 
            // 
            this.txt_invName.CustomButton.Image = null;
            this.txt_invName.CustomButton.Location = new System.Drawing.Point(208, 1);
            this.txt_invName.CustomButton.Margin = new System.Windows.Forms.Padding(2);
            this.txt_invName.CustomButton.Name = "";
            this.txt_invName.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txt_invName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_invName.CustomButton.TabIndex = 1;
            this.txt_invName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_invName.CustomButton.UseSelectable = true;
            this.txt_invName.CustomButton.Visible = false;
            this.txt_invName.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txt_invName.Lines = new string[0];
            this.txt_invName.Location = new System.Drawing.Point(14, 150);
            this.txt_invName.Margin = new System.Windows.Forms.Padding(2);
            this.txt_invName.MaxLength = 32767;
            this.txt_invName.Name = "txt_invName";
            this.txt_invName.PasswordChar = '\0';
            this.txt_invName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_invName.SelectedText = "";
            this.txt_invName.SelectionLength = 0;
            this.txt_invName.SelectionStart = 0;
            this.txt_invName.ShortcutsEnabled = true;
            this.txt_invName.Size = new System.Drawing.Size(236, 29);
            this.txt_invName.TabIndex = 60;
            this.txt_invName.UseSelectable = true;
            this.txt_invName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_invName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel5.Location = new System.Drawing.Point(289, 133);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(54, 15);
            this.metroLabel5.TabIndex = 66;
            this.metroLabel5.Text = "Unit Price";
            // 
            // txt_unitPrice
            // 
            // 
            // 
            // 
            this.txt_unitPrice.CustomButton.Image = null;
            this.txt_unitPrice.CustomButton.Location = new System.Drawing.Point(208, 1);
            this.txt_unitPrice.CustomButton.Margin = new System.Windows.Forms.Padding(2);
            this.txt_unitPrice.CustomButton.Name = "";
            this.txt_unitPrice.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txt_unitPrice.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_unitPrice.CustomButton.TabIndex = 1;
            this.txt_unitPrice.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_unitPrice.CustomButton.UseSelectable = true;
            this.txt_unitPrice.CustomButton.Visible = false;
            this.txt_unitPrice.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txt_unitPrice.Lines = new string[0];
            this.txt_unitPrice.Location = new System.Drawing.Point(289, 150);
            this.txt_unitPrice.Margin = new System.Windows.Forms.Padding(2);
            this.txt_unitPrice.MaxLength = 32767;
            this.txt_unitPrice.Name = "txt_unitPrice";
            this.txt_unitPrice.PasswordChar = '\0';
            this.txt_unitPrice.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_unitPrice.SelectedText = "";
            this.txt_unitPrice.SelectionLength = 0;
            this.txt_unitPrice.SelectionStart = 0;
            this.txt_unitPrice.ShortcutsEnabled = true;
            this.txt_unitPrice.Size = new System.Drawing.Size(236, 29);
            this.txt_unitPrice.TabIndex = 64;
            this.txt_unitPrice.UseSelectable = true;
            this.txt_unitPrice.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_unitPrice.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel7.Location = new System.Drawing.Point(289, 192);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(90, 15);
            this.metroLabel7.TabIndex = 70;
            this.metroLabel7.Text = "Quantity in Stock";
            // 
            // txt_stockQuan
            // 
            // 
            // 
            // 
            this.txt_stockQuan.CustomButton.Image = null;
            this.txt_stockQuan.CustomButton.Location = new System.Drawing.Point(208, 1);
            this.txt_stockQuan.CustomButton.Margin = new System.Windows.Forms.Padding(2);
            this.txt_stockQuan.CustomButton.Name = "";
            this.txt_stockQuan.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txt_stockQuan.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_stockQuan.CustomButton.TabIndex = 1;
            this.txt_stockQuan.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_stockQuan.CustomButton.UseSelectable = true;
            this.txt_stockQuan.CustomButton.Visible = false;
            this.txt_stockQuan.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txt_stockQuan.Lines = new string[0];
            this.txt_stockQuan.Location = new System.Drawing.Point(289, 209);
            this.txt_stockQuan.Margin = new System.Windows.Forms.Padding(2);
            this.txt_stockQuan.MaxLength = 32767;
            this.txt_stockQuan.Name = "txt_stockQuan";
            this.txt_stockQuan.PasswordChar = '\0';
            this.txt_stockQuan.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_stockQuan.SelectedText = "";
            this.txt_stockQuan.SelectionLength = 0;
            this.txt_stockQuan.SelectionStart = 0;
            this.txt_stockQuan.ShortcutsEnabled = true;
            this.txt_stockQuan.Size = new System.Drawing.Size(236, 29);
            this.txt_stockQuan.TabIndex = 68;
            this.txt_stockQuan.UseSelectable = true;
            this.txt_stockQuan.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_stockQuan.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel9.Location = new System.Drawing.Point(289, 80);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(83, 15);
            this.metroLabel9.TabIndex = 74;
            this.metroLabel9.Text = "Inventory Value";
            // 
            // txt_invValue
            // 
            this.txt_invValue.BackColor = System.Drawing.Color.LightGray;
            // 
            // 
            // 
            this.txt_invValue.CustomButton.Image = null;
            this.txt_invValue.CustomButton.Location = new System.Drawing.Point(208, 2);
            this.txt_invValue.CustomButton.Margin = new System.Windows.Forms.Padding(2);
            this.txt_invValue.CustomButton.Name = "";
            this.txt_invValue.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txt_invValue.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_invValue.CustomButton.TabIndex = 1;
            this.txt_invValue.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_invValue.CustomButton.UseSelectable = true;
            this.txt_invValue.CustomButton.Visible = false;
            this.txt_invValue.Enabled = false;
            this.txt_invValue.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txt_invValue.Lines = new string[0];
            this.txt_invValue.Location = new System.Drawing.Point(289, 96);
            this.txt_invValue.Margin = new System.Windows.Forms.Padding(2);
            this.txt_invValue.MaxLength = 32767;
            this.txt_invValue.Name = "txt_invValue";
            this.txt_invValue.PasswordChar = '\0';
            this.txt_invValue.ReadOnly = true;
            this.txt_invValue.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_invValue.SelectedText = "";
            this.txt_invValue.SelectionLength = 0;
            this.txt_invValue.SelectionStart = 0;
            this.txt_invValue.ShortcutsEnabled = true;
            this.txt_invValue.Size = new System.Drawing.Size(236, 30);
            this.txt_invValue.TabIndex = 72;
            this.txt_invValue.UseCustomBackColor = true;
            this.txt_invValue.UseSelectable = true;
            this.txt_invValue.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_invValue.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel1.Location = new System.Drawing.Point(14, 192);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(54, 15);
            this.metroLabel1.TabIndex = 84;
            this.metroLabel1.Text = "Category";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel4.Location = new System.Drawing.Point(835, 133);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(104, 15);
            this.metroLabel4.TabIndex = 82;
            this.metroLabel4.Text = "Quantity in Reorder";
            // 
            // txt_reorderQuan
            // 
            // 
            // 
            // 
            this.txt_reorderQuan.CustomButton.Image = null;
            this.txt_reorderQuan.CustomButton.Location = new System.Drawing.Point(208, 1);
            this.txt_reorderQuan.CustomButton.Margin = new System.Windows.Forms.Padding(2);
            this.txt_reorderQuan.CustomButton.Name = "";
            this.txt_reorderQuan.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txt_reorderQuan.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_reorderQuan.CustomButton.TabIndex = 1;
            this.txt_reorderQuan.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_reorderQuan.CustomButton.UseSelectable = true;
            this.txt_reorderQuan.CustomButton.Visible = false;
            this.txt_reorderQuan.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txt_reorderQuan.Lines = new string[0];
            this.txt_reorderQuan.Location = new System.Drawing.Point(835, 150);
            this.txt_reorderQuan.Margin = new System.Windows.Forms.Padding(2);
            this.txt_reorderQuan.MaxLength = 32767;
            this.txt_reorderQuan.Name = "txt_reorderQuan";
            this.txt_reorderQuan.PasswordChar = '\0';
            this.txt_reorderQuan.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_reorderQuan.SelectedText = "";
            this.txt_reorderQuan.SelectionLength = 0;
            this.txt_reorderQuan.SelectionStart = 0;
            this.txt_reorderQuan.ShortcutsEnabled = true;
            this.txt_reorderQuan.Size = new System.Drawing.Size(236, 29);
            this.txt_reorderQuan.TabIndex = 81;
            this.txt_reorderQuan.UseSelectable = true;
            this.txt_reorderQuan.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_reorderQuan.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel6.Location = new System.Drawing.Point(561, 80);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(76, 15);
            this.metroLabel6.TabIndex = 80;
            this.metroLabel6.Text = "Reorder Point";
            // 
            // txt_reorderPoint
            // 
            this.txt_reorderPoint.BackColor = System.Drawing.Color.LightGray;
            // 
            // 
            // 
            this.txt_reorderPoint.CustomButton.Image = null;
            this.txt_reorderPoint.CustomButton.Location = new System.Drawing.Point(208, 1);
            this.txt_reorderPoint.CustomButton.Margin = new System.Windows.Forms.Padding(2);
            this.txt_reorderPoint.CustomButton.Name = "";
            this.txt_reorderPoint.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txt_reorderPoint.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_reorderPoint.CustomButton.TabIndex = 1;
            this.txt_reorderPoint.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_reorderPoint.CustomButton.UseSelectable = true;
            this.txt_reorderPoint.CustomButton.Visible = false;
            this.txt_reorderPoint.Enabled = false;
            this.txt_reorderPoint.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txt_reorderPoint.Lines = new string[0];
            this.txt_reorderPoint.Location = new System.Drawing.Point(561, 97);
            this.txt_reorderPoint.Margin = new System.Windows.Forms.Padding(2);
            this.txt_reorderPoint.MaxLength = 32767;
            this.txt_reorderPoint.Name = "txt_reorderPoint";
            this.txt_reorderPoint.PasswordChar = '\0';
            this.txt_reorderPoint.ReadOnly = true;
            this.txt_reorderPoint.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_reorderPoint.SelectedText = "";
            this.txt_reorderPoint.SelectionLength = 0;
            this.txt_reorderPoint.SelectionStart = 0;
            this.txt_reorderPoint.ShortcutsEnabled = true;
            this.txt_reorderPoint.Size = new System.Drawing.Size(236, 29);
            this.txt_reorderPoint.TabIndex = 79;
            this.txt_reorderPoint.UseCustomBackColor = true;
            this.txt_reorderPoint.UseSelectable = true;
            this.txt_reorderPoint.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_reorderPoint.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel8.Location = new System.Drawing.Point(561, 192);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(113, 15);
            this.metroLabel8.TabIndex = 78;
            this.metroLabel8.Text = "Reorder Time in Days";
            // 
            // txt_leadTime
            // 
            // 
            // 
            // 
            this.txt_leadTime.CustomButton.Image = null;
            this.txt_leadTime.CustomButton.Location = new System.Drawing.Point(208, 1);
            this.txt_leadTime.CustomButton.Margin = new System.Windows.Forms.Padding(2);
            this.txt_leadTime.CustomButton.Name = "";
            this.txt_leadTime.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txt_leadTime.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_leadTime.CustomButton.TabIndex = 1;
            this.txt_leadTime.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_leadTime.CustomButton.UseSelectable = true;
            this.txt_leadTime.CustomButton.Visible = false;
            this.txt_leadTime.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txt_leadTime.Lines = new string[0];
            this.txt_leadTime.Location = new System.Drawing.Point(561, 209);
            this.txt_leadTime.Margin = new System.Windows.Forms.Padding(2);
            this.txt_leadTime.MaxLength = 32767;
            this.txt_leadTime.Name = "txt_leadTime";
            this.txt_leadTime.PasswordChar = '\0';
            this.txt_leadTime.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_leadTime.SelectedText = "";
            this.txt_leadTime.SelectionLength = 0;
            this.txt_leadTime.SelectionStart = 0;
            this.txt_leadTime.ShortcutsEnabled = true;
            this.txt_leadTime.Size = new System.Drawing.Size(236, 29);
            this.txt_leadTime.TabIndex = 77;
            this.txt_leadTime.UseSelectable = true;
            this.txt_leadTime.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_leadTime.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel10.Location = new System.Drawing.Point(561, 133);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(110, 15);
            this.metroLabel10.TabIndex = 76;
            this.metroLabel10.Text = "Average Daily Usage";
            // 
            // txt_avgDailyUsage
            // 
            // 
            // 
            // 
            this.txt_avgDailyUsage.CustomButton.Image = null;
            this.txt_avgDailyUsage.CustomButton.Location = new System.Drawing.Point(208, 1);
            this.txt_avgDailyUsage.CustomButton.Margin = new System.Windows.Forms.Padding(2);
            this.txt_avgDailyUsage.CustomButton.Name = "";
            this.txt_avgDailyUsage.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txt_avgDailyUsage.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_avgDailyUsage.CustomButton.TabIndex = 1;
            this.txt_avgDailyUsage.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_avgDailyUsage.CustomButton.UseSelectable = true;
            this.txt_avgDailyUsage.CustomButton.Visible = false;
            this.txt_avgDailyUsage.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txt_avgDailyUsage.Lines = new string[0];
            this.txt_avgDailyUsage.Location = new System.Drawing.Point(561, 150);
            this.txt_avgDailyUsage.Margin = new System.Windows.Forms.Padding(2);
            this.txt_avgDailyUsage.MaxLength = 32767;
            this.txt_avgDailyUsage.Name = "txt_avgDailyUsage";
            this.txt_avgDailyUsage.PasswordChar = '\0';
            this.txt_avgDailyUsage.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_avgDailyUsage.SelectedText = "";
            this.txt_avgDailyUsage.SelectionLength = 0;
            this.txt_avgDailyUsage.SelectionStart = 0;
            this.txt_avgDailyUsage.ShortcutsEnabled = true;
            this.txt_avgDailyUsage.Size = new System.Drawing.Size(236, 29);
            this.txt_avgDailyUsage.TabIndex = 75;
            this.txt_avgDailyUsage.UseSelectable = true;
            this.txt_avgDailyUsage.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_avgDailyUsage.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // cmbo_invCat
            // 
            this.cmbo_invCat.FormattingEnabled = true;
            this.cmbo_invCat.ItemHeight = 23;
            this.cmbo_invCat.Location = new System.Drawing.Point(14, 209);
            this.cmbo_invCat.Margin = new System.Windows.Forms.Padding(2);
            this.cmbo_invCat.Name = "cmbo_invCat";
            this.cmbo_invCat.Size = new System.Drawing.Size(236, 29);
            this.cmbo_invCat.TabIndex = 85;
            this.cmbo_invCat.UseSelectable = true;
            // 
            // btn_Remove
            // 
            this.btn_Remove.BackColor = System.Drawing.SystemColors.Control;
            this.btn_Remove.Location = new System.Drawing.Point(914, 286);
            this.btn_Remove.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(296, 29);
            this.btn_Remove.TabIndex = 86;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseSelectable = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // btn_catClear
            // 
            this.btn_catClear.Location = new System.Drawing.Point(195, 328);
            this.btn_catClear.Margin = new System.Windows.Forms.Padding(2);
            this.btn_catClear.Name = "btn_catClear";
            this.btn_catClear.Size = new System.Drawing.Size(114, 29);
            this.btn_catClear.TabIndex = 87;
            this.btn_catClear.Text = "Clear Category";
            this.btn_catClear.UseSelectable = true;
            this.btn_catClear.Click += new System.EventHandler(this.btn_catClear_Click);
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel11.Location = new System.Drawing.Point(835, 192);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(53, 15);
            this.metroLabel11.TabIndex = 89;
            this.metroLabel11.Text = "Unit Type";
            // 
            // txt_unitType
            // 
            // 
            // 
            // 
            this.txt_unitType.CustomButton.Image = null;
            this.txt_unitType.CustomButton.Location = new System.Drawing.Point(208, 1);
            this.txt_unitType.CustomButton.Margin = new System.Windows.Forms.Padding(2);
            this.txt_unitType.CustomButton.Name = "";
            this.txt_unitType.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txt_unitType.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_unitType.CustomButton.TabIndex = 1;
            this.txt_unitType.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_unitType.CustomButton.UseSelectable = true;
            this.txt_unitType.CustomButton.Visible = false;
            this.txt_unitType.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txt_unitType.Lines = new string[0];
            this.txt_unitType.Location = new System.Drawing.Point(835, 209);
            this.txt_unitType.Margin = new System.Windows.Forms.Padding(2);
            this.txt_unitType.MaxLength = 32767;
            this.txt_unitType.Name = "txt_unitType";
            this.txt_unitType.PasswordChar = '\0';
            this.txt_unitType.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_unitType.SelectedText = "";
            this.txt_unitType.SelectionLength = 0;
            this.txt_unitType.SelectionStart = 0;
            this.txt_unitType.ShortcutsEnabled = true;
            this.txt_unitType.Size = new System.Drawing.Size(236, 29);
            this.txt_unitType.TabIndex = 88;
            this.txt_unitType.UseSelectable = true;
            this.txt_unitType.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_unitType.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Eats2Go_InvManageFrm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1223, 792);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.txt_unitType);
            this.Controls.Add(this.btn_catClear);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.cmbo_invCat);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.txt_reorderQuan);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.txt_reorderPoint);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.txt_leadTime);
            this.Controls.Add(this.metroLabel10);
            this.Controls.Add(this.txt_avgDailyUsage);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.txt_invValue);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.txt_stockQuan);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.txt_unitPrice);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.txt_invName);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.btn_invClear);
            this.Controls.Add(this.btn_invSave);
            this.Controls.Add(this.btn_invAdd);
            this.Controls.Add(this.txt_invID);
            this.Controls.Add(this.btn_invLoad);
            this.Controls.Add(this.btn_invSearch);
            this.Controls.Add(this.txt_invSearch);
            this.Controls.Add(this.cmbo_catSearch);
            this.Controls.Add(this.data_Inv);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Eats2Go_InvManageFrm1";
            this.Padding = new System.Windows.Forms.Padding(11, 60, 11, 11);
            this.Style = MetroFramework.MetroColorStyle.Orange;
            this.Text = "Eats2Go Inventory Management System";
            this.Load += new System.EventHandler(this.Eats2Go_InvManageFrm1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.data_Inv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroGrid data_Inv;
        private MetroFramework.Controls.MetroComboBox cmbo_catSearch;
        private MetroFramework.Controls.MetroTextBox txt_invSearch;
        private MetroFramework.Controls.MetroButton btn_invSearch;
        private MetroFramework.Controls.MetroButton btn_invLoad;
        private MetroFramework.Controls.MetroTextBox txt_invID;
        private MetroFramework.Controls.MetroButton btn_invAdd;
        private MetroFramework.Controls.MetroButton btn_invSave;
        private MetroFramework.Controls.MetroButton btn_invClear;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox txt_invName;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroTextBox txt_unitPrice;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroTextBox txt_stockQuan;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroTextBox txt_invValue;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroTextBox txt_reorderQuan;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTextBox txt_reorderPoint;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroTextBox txt_leadTime;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroTextBox txt_avgDailyUsage;
        private MetroFramework.Controls.MetroButton btn_Remove;
        private MetroFramework.Controls.MetroComboBox cmbo_invCat;
        private MetroFramework.Controls.MetroButton btn_catClear;
        private System.Windows.Forms.DataGridViewTextBoxColumn invID;
        private System.Windows.Forms.DataGridViewTextBoxColumn invName;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockQuan;
        private System.Windows.Forms.DataGridViewTextBoxColumn invValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn avgDailyUsage;
        private System.Windows.Forms.DataGridViewTextBoxColumn leadTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn reorderPoint;
        private System.Windows.Forms.DataGridViewTextBoxColumn reorderQuan;
        private System.Windows.Forms.DataGridViewTextBoxColumn invCat;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitType;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroTextBox txt_unitType;
    }
}

