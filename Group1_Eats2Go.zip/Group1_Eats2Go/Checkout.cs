﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using MetroFramework.Forms;
using static Group1_Eats2Go.frmHome;

namespace Group1_Eats2Go
{
    public partial class frmCheckout : MetroForm
    {
      

        List<Order> orderCart = new List<Order>();
        public frmCheckout(string orderDetails, string totalAmount)
        {
            InitializeComponent();

            txtMenuOrderchk.Text = orderDetails;
            txtTotalChk.Text = totalAmount;
        }

        private void frmCheckout_Load(object sender, EventArgs e)
        {

        }
        
        private void CashConfirm_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Paid with CASH!", "Checkout", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void Card_Confirmbtn_Click(object sender, EventArgs e)
        {
            CardDetails carddtl = new CardDetails(this);
            carddtl.Show();
        }


        private void chckCancelbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
