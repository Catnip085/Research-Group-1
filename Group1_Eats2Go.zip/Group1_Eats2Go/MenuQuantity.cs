﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using MetroFramework.Forms;

namespace Group1_Eats2Go
{
    public partial class frmMenuQuantity : MetroForm
    {
        public int Quantity { get; private set; }

        public frmMenuQuantity()
        {
            InitializeComponent();
        }

        private void frmMenuQuantity_Load(object sender, EventArgs e)
        {

        }

        private void btnMenuQuantityAdd_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtMenuQuantity.Text, out int quantity))
            {
                Quantity = quantity;
                DialogResult = DialogResult.OK; 
                Close(); 
            }
            else
            {
                MessageBox.Show("Please enter a valid quantity."); 
            }
        }
    }
}
