﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using MetroFramework.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;

namespace Group1_Eats2Go
{
    public partial class frmHome : MetroForm
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader rdr;
        
        public class Order
        {
            public string orderName { get; set; }
            public int Quantity { get; set; }
            public decimal Price { get; set; }
        }

        List<Order> orderCart = new List<Order>();

        private void AddToOrder(string orderName, int quantity, decimal price)
        {
            Order existingOrder = orderCart.FirstOrDefault(order => order.orderName == orderName);
            if (existingOrder != null)
            {
                existingOrder.Quantity += quantity;
            }
            else
            {
                orderCart.Add(new Order { orderName = orderName, Quantity = quantity, Price = price});
            }
            UpdateOrder();
        }

        private void UpdateOrder()
        {
            decimal totalPrice = 0;
            txtMenuOrder.Clear();
            foreach (var order in orderCart)
            {
                totalPrice += order.Quantity * order.Price;
                txtMenuOrder.AppendText($"{order.orderName}:  {order.Quantity}  Php {order.Price}{Environment.NewLine}");
            }
            txtMenuTotal.Text = totalPrice.ToString("0.00");
        }

        public frmHome()
        {
            InitializeComponent();
            txtMenuOrder.Multiline = true;
        }

        private void frmHome_Load(object sender, EventArgs e)
        {
            SetConnection();
            LoadCustomers();
            LoadFood();
            LoadSales();
        }   

        private void SetConnection() 
        {
            con = new SqlConnection(
                @"Data Source = LAPTOP-R2S9JSLB\SQLEXPRESS; 
                Initial Catalog = Eats2GO_DB2; 
                user ID = sa; 
                password = sysadmin;");
        }

        private void LoadCustomers() 
        {
            dataSalesCustomer.Rows.Clear();
            con.Open();
            cmd = new SqlCommand(@"SELECT custID, custDate 
                                  FROM CUSTOMER;", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                dataSalesCustomer.Rows.Add(rdr[0].ToString(), rdr[1].ToString());
            }
            con.Close();
        }

        private void LoadFood()
        {
            dataSalesFood.Rows.Clear();
            con.Open();
            cmd = new SqlCommand(@"SELECT  foodID, foodName, foodType, foodPrice
                                  FROM FOOD;", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                dataSalesFood.Rows.Add(rdr[0].ToString(),
                    rdr[1].ToString(), rdr[2].ToString(),
                    rdr[3].ToString());

                
            }
            con.Close();
        }

        private void LoadSales() 
        {
            dataSales.Rows.Clear();
            con.Open();
            cmd = new SqlCommand(@"SELECT SALES.saleID, CUSTOMER.custID, FOOD.foodName, SALES.saleQuantity, 
                       CUSTOMER.custDate,  
                       SALES.saleQuantity * FOOD.foodPrice as 'TotalPrice'
                       FROM SALES 
                       INNER JOIN FOOD ON SALES.foodID = FOOD.foodID 
                       INNER JOIN CUSTOMER ON SALES.custID = CUSTOMER.custID;", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                dataSales.Rows.Add(
                    rdr[0].ToString(), 
                    rdr[1].ToString(), 
                    rdr[2].ToString(),
                    rdr[3].ToString(),
                    rdr[4].ToString(),
                    rdr[5].ToString());
            }
            con.Close();
        }

        private void LoadFoodSearch(string searchText)
        {
            dataSalesFood.Rows.Clear();
            con.Open();
            cmd = new SqlCommand(@"SELECT foodID, foodName, foodType, 
                foodPrice FROM FOOD 
                WHERE foodName LIKE '%" + searchText
                + "%' OR foodType LIKE '%" + searchText
                + "%' OR foodPrice LIKE '%" + searchText
                + "%';;", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                dataSalesFood.Rows.Add(rdr[0].ToString(),
                    rdr[1].ToString(), rdr[2].ToString(),
                    rdr[3].ToString());
            }
            con.Close();
        }

        private void LoadSalesSearch(string searchText)
        {
            dataSales.Rows.Clear();
            con.Open();
            cmd = new SqlCommand(@"SELECT saleID, saleQuantity, saleDatePurchase, 
                saleQuantity * foodPrice as 'TotalPrice'
                FROM SALES INNER JOIN FOOD
                ON SALES.foodID = FOOD.foodID 
                INNER JOIN CUSTOMER 
                ON SALES.custID = CUSTOMER.custID  
                WHERE SALES.custID LIKE '%" + searchText
                + "%' OR SALES.foodID LIKE '%"+ searchText 
                +"%' OR saleQuantity LIKE '%"+ searchText 
                + "%'OR saleDatePurchase LIKE '%"+ searchText 
                + "%';;", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                dataSales.Rows.Add(rdr[0].ToString(), rdr[1].ToString(), rdr[2].ToString(),
                    rdr[3].ToString(), rdr[4].ToString(), rdr[5].ToString());
            }
            con.Close();
        }

        //These buttons are used to nagivate tab control
        private void btnMenuMainCourse_Click(object sender, EventArgs e)
        {
            tabMenuControl.SelectedIndex = 0;
        }

        private void btnMenuDrinks_Click(object sender, EventArgs e)
        {
            tabMenuControl.SelectedIndex = 1;
        }

        private void btnMenuDessert_Click(object sender, EventArgs e)
        {
            tabMenuControl.SelectedIndex = 2;
        }

        private void btnMenuFavorites_Click(object sender, EventArgs e)
        {
            tabMenuControl.SelectedIndex = 3;
        }
        // These buttons will open Quantity form
        private void btnMenuMainCourseOne_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("Tuna Sandwich", quantity, price);
            }
        }   

        private void btnMenuMainCourseTwo_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("Chicken Sandwich", quantity, price);
            }
        }

        private void btnMenuMainCourseThree_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("Hotdog", quantity, price);
            }
        }

        private void btnMenuMainCourseFour_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("Cheese Hotdog", quantity, price);
            }
        }

        private void btnMenuMainCourseFive_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("Tuna Waffle", quantity, price);
            }
        }

        private void btnMenuMainCourseSix_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("B&C Waffle", quantity, price);
            }
        }

        private void btnMenuMainCourseSeven_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("Chicken Burger", quantity, price);
            }
        }

        private void btnMenuMainCourseEight_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("Cheese Burger", quantity, price);
            }
        }

        private void btnMenuDrinksOne_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 20.00m;
                AddToOrder("Coke", quantity, price);
            }
        }

        private void btnMenuDrinksTwo_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 20.00m;
                AddToOrder("Sprite", quantity, price);
            }
        }

        private void btnMenuDrinksThree_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 20.00m;
                AddToOrder("Fanta", quantity, price);
            }
        }

        private void btnMenuDrinksFour_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 20.00m;
                AddToOrder("Mountain Dew", quantity, price);
            }
        }

        private void btnMenuDrinksFive_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 12.00m;
                AddToOrder("Pineapple Juice", quantity, price);
            }
        }

        private void btnMenuDrinksSeven_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 12.00m;
                AddToOrder("Orange Juice", quantity, price);
            }
        }

        private void btnMenuDessertOne_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("Halo-Halo", quantity, price);
            }
        }

        private void btnMenuDessertTwo_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 30.00m;
                AddToOrder("Leche Flan", quantity, price);
            }
        }

        private void btnMenuDessertThree_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 25.00m;
                AddToOrder("Ube Cheese Pie", quantity, price);
            }
        }

        private void btnMenuDessertFour_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 15.00m;
                AddToOrder("Churro Donut", quantity, price);
            }
        }

        private void btnMenuFavoritesOne_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("Chicken Sandwich", quantity, price);
            }
        }

        private void btnMenuFavoritesTwo_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("Cheese Hotdog", quantity, price);
            }
        }

        private void btnMenuFavoritesThree_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("B&C Waffle", quantity, price);
            }
        }

        private void btnMenuFavoritesFour_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("Halo-Halo", quantity, price);
            }
        }

        private void btnMenuFavoritesFive_Click(object sender, EventArgs e)
        {
            frmMenuQuantity quantityForm = new frmMenuQuantity();

            if (quantityForm.ShowDialog() == DialogResult.OK)
            {
                int quantity = quantityForm.Quantity;
                decimal price = 35.00m;
                AddToOrder("Ube Cheese Pie", quantity, price);
            }
        }

        private void btnMenuCheckOut_Click(object sender, EventArgs e)
        {
            
            string orderDetails = txtMenuOrder.Text;
            string totalAmount = txtMenuTotal.Text;

            frmCheckout formCheckout = new frmCheckout(orderDetails, totalAmount);

            if (formCheckout.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void btnMenuCancel_Click(object sender, EventArgs e)
        {
            txtMenuOrder.Clear();
            orderCart.Clear();
            txtMenuTotal.Text = "0.00";
        }
        // Search btn and bar for Sales
        private void btnSalesSearch_Click(object sender, EventArgs e)
        {
            LoadFoodSearch(txtSaleSearch.Text);
            LoadSalesSearch(txtSaleSearch.Text);
        }

        private void btnSalesRefund_Click(object sender, EventArgs e)
        {
            
        }
    }
}
