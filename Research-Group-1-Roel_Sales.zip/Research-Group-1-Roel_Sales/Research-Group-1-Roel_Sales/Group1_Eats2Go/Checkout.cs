﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using MetroFramework.Forms;
using static Group1_Eats2Go.frmHome;

namespace Group1_Eats2Go
{
    public partial class frmCheckout : MetroForm
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader rdr;

        
        public frmCheckout()
        {
            InitializeComponent();
        }
        private void SetConnection()
        {
            con = new SqlConnection(
                @"Data Source = LAPTOP-R2S9JSLB\SQLEXPRESS; 
                Initial Catalog = Eats2GO_DB2; 
                user ID = sa; 
                password = sysadmin;");
        }
        private void frmCheckout_Load(object sender, EventArgs e)
        {

        }

        List<Order> orderCart = new List<Order>();
        public frmCheckout(string orderDetails, string totalAmount)
        {
            InitializeComponent();

            txtMenuOrderchk.Text = orderDetails;
            txtTotalChk.Text = totalAmount;
            
            
        }

        private void CashConfirm_Click(object sender, EventArgs e)
        {
            InsertOrdersToDatabase();
        }

        public void InsertOrdersToDatabase()
        {
            // Split the multiline order details into individual lines
            string[] orderLines = txtMenuOrderchk.Text.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);

            SqlConnection con = null;

            try
            {
                // Initialize and open the database connection
                con = new SqlConnection(
                    @"Data Source = LAPTOP-R2S9JSLB\SQLEXPRESS; 
              Initial Catalog = Eats2GO_DB2; 
              user ID = sa; 
              password = sysadmin;");
                con.Open();

                // Iterate over each order line
                foreach (string line in orderLines)
                {
                    // Assuming the format is "foodName: quantity Php price"
                    string[] orderParts = line.Split(new[] { ':', ' ' }, StringSplitOptions.RemoveEmptyEntries);

                    if (orderParts.Length >= 2)
                    {
                        string foodName = orderParts[0].Trim();
                        int quantity = int.Parse(orderParts[1].Trim());

               
                        int foodID = GetFoodID(con, foodName);

                        if (foodID != 0)
                        {

                            SqlCommand cmd = new SqlCommand(@"INSERT INTO SALES (custID, foodID, saleQuantity, saleDatePurchase) 
                                                      VALUES (@CustID, @FoodID, @SaleQuantity, @SaleDatePurchase)", con);

                            
                            int custID = 4; 
                            cmd.Parameters.AddWithValue("@CustID", custID);
                            cmd.Parameters.AddWithValue("@FoodID", foodID);
                            cmd.Parameters.AddWithValue("@SaleQuantity", quantity);
                            cmd.Parameters.AddWithValue("@SaleDatePurchase", DateTime.Now);

                            cmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MetroFramework.MetroMessageBox.Show(this, $"Food ID for {foodName} not found.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }

                MetroFramework.MetroMessageBox.Show(this, "Orders have been successfully inserted!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MetroFramework.MetroMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
        }

        private int GetFoodID(SqlConnection con, string foodName)
        {
            int foodID = 0;

            SqlCommand cmd = new SqlCommand(@"SELECT foodID FROM FOOD WHERE foodName = @FoodName", con);
            cmd.Parameters.AddWithValue("@FoodName", foodName);

            SqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                foodID = Convert.ToInt32(rdr["foodID"]);
            }
            rdr.Close();

            return foodID;
        }



        private void Card_Confirmbtn_Click(object sender, EventArgs e)
        {
            CardDetails carddtl = new CardDetails(this);
            carddtl.Show();
        }

        private void chckCancelbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
