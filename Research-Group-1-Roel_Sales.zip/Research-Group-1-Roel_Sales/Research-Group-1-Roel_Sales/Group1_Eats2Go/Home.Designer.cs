﻿namespace Group1_Eats2Go
{
    partial class frmHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHome));
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.btnMenuCancel = new MetroFramework.Controls.MetroButton();
            this.tabMenuControl = new MetroFramework.Controls.MetroTabControl();
            this.tabMainCoursePage = new MetroFramework.Controls.MetroTabPage();
            this.metroTextBox6 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox7 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox8 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox9 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox2 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox5 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox3 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox4 = new MetroFramework.Controls.MetroTextBox();
            this.btnMenuMainCourseEight = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseSeven = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseSix = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseFive = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseFour = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseThree = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseTwo = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseOne = new MetroFramework.Controls.MetroButton();
            this.tabDrinksPage = new MetroFramework.Controls.MetroTabPage();
            this.metroTextBox14 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox15 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox10 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox11 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox12 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox13 = new MetroFramework.Controls.MetroTextBox();
            this.btnMenuDrinksSeven = new MetroFramework.Controls.MetroButton();
            this.btnMenuDrinksFive = new MetroFramework.Controls.MetroButton();
            this.btnMenuDrinksFour = new MetroFramework.Controls.MetroButton();
            this.btnMenuDrinksThree = new MetroFramework.Controls.MetroButton();
            this.btnMenuDrinksTwo = new MetroFramework.Controls.MetroButton();
            this.btnMenuDrinksOne = new MetroFramework.Controls.MetroButton();
            this.tabDessertPage = new MetroFramework.Controls.MetroTabPage();
            this.metroTextBox16 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox17 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox18 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox19 = new MetroFramework.Controls.MetroTextBox();
            this.btnMenuDessertFour = new MetroFramework.Controls.MetroButton();
            this.btnMenuDessertThree = new MetroFramework.Controls.MetroButton();
            this.btnMenuDessertTwo = new MetroFramework.Controls.MetroButton();
            this.btnMenuDessertOne = new MetroFramework.Controls.MetroButton();
            this.tabFavoritesPage = new MetroFramework.Controls.MetroTabPage();
            this.metroTextBox24 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox20 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox21 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox22 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox23 = new MetroFramework.Controls.MetroTextBox();
            this.btnMenuFavoritesFive = new MetroFramework.Controls.MetroButton();
            this.btnMenuFavoritesFour = new MetroFramework.Controls.MetroButton();
            this.btnMenuFavoritesThree = new MetroFramework.Controls.MetroButton();
            this.btnMenuFavoritesTwo = new MetroFramework.Controls.MetroButton();
            this.btnMenuFavoritesOne = new MetroFramework.Controls.MetroButton();
            this.btnMenuDrinks = new MetroFramework.Controls.MetroButton();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.btnMenuFavorites = new MetroFramework.Controls.MetroButton();
            this.btnMenuDessert = new MetroFramework.Controls.MetroButton();
            this.txtMenuTotal = new MetroFramework.Controls.MetroTextBox();
            this.btnMenuMainCourse = new MetroFramework.Controls.MetroButton();
            this.txtMenuOrder = new MetroFramework.Controls.MetroTextBox();
            this.btnMenuCheckOut = new MetroFramework.Controls.MetroButton();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.btnSalesRefund = new MetroFramework.Controls.MetroButton();
            this.dataSalesFood = new MetroFramework.Controls.MetroGrid();
            this.food_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.food_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.food_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.food_Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataSalesCustomer = new MetroFramework.Controls.MetroGrid();
            this.customer_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customer_Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSalesSearch = new MetroFramework.Controls.MetroButton();
            this.txtSaleSearch = new MetroFramework.Controls.MetroTextBox();
            this.dataSales = new MetroFramework.Controls.MetroGrid();
            this.sales_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sales_customerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sales_FoodName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sales_Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sales_Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sales_TotalPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroDateTime1 = new MetroFramework.Controls.MetroDateTime();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            this.tabMenuControl.SuspendLayout();
            this.tabMainCoursePage.SuspendLayout();
            this.tabDrinksPage.SuspendLayout();
            this.tabDessertPage.SuspendLayout();
            this.tabFavoritesPage.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSalesFood)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSalesCustomer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSales)).BeginInit();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Location = new System.Drawing.Point(31, 96);
            this.metroTabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 1;
            this.metroTabControl1.Size = new System.Drawing.Size(1691, 762);
            this.metroTabControl1.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTabControl1.TabIndex = 0;
            this.metroTabControl1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.metroTabControl1.UseSelectable = true;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.BackColor = System.Drawing.Color.Orange;
            this.metroTabPage1.Controls.Add(this.metroLabel1);
            this.metroTabPage1.Controls.Add(this.metroTextBox1);
            this.metroTabPage1.Controls.Add(this.btnMenuCancel);
            this.metroTabPage1.Controls.Add(this.tabMenuControl);
            this.metroTabPage1.Controls.Add(this.btnMenuDrinks);
            this.metroTabPage1.Controls.Add(this.metroLabel4);
            this.metroTabPage1.Controls.Add(this.btnMenuFavorites);
            this.metroTabPage1.Controls.Add(this.btnMenuDessert);
            this.metroTabPage1.Controls.Add(this.txtMenuTotal);
            this.metroTabPage1.Controls.Add(this.btnMenuMainCourse);
            this.metroTabPage1.Controls.Add(this.txtMenuOrder);
            this.metroTabPage1.Controls.Add(this.btnMenuCheckOut);
            this.metroTabPage1.Controls.Add(this.metroLabel3);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 12;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 41);
            this.metroTabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(1683, 717);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "Menu";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 0;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(1325, 252);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(41, 20);
            this.metroLabel1.TabIndex = 9;
            this.metroLabel1.Text = "Date:";
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.Image = null;
            this.metroTextBox1.CustomButton.Location = new System.Drawing.Point(115, 2);
            this.metroTextBox1.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = 1;
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = false;
            this.metroTextBox1.Lines = new string[0];
            this.metroTextBox1.Location = new System.Drawing.Point(1412, 247);
            this.metroTextBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.Size = new System.Drawing.Size(112, 28);
            this.metroTextBox1.TabIndex = 8;
            this.metroTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnMenuCancel
            // 
            this.btnMenuCancel.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Background;
            this.btnMenuCancel.Location = new System.Drawing.Point(1412, 465);
            this.btnMenuCancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuCancel.Name = "btnMenuCancel";
            this.btnMenuCancel.Size = new System.Drawing.Size(241, 65);
            this.btnMenuCancel.TabIndex = 7;
            this.btnMenuCancel.Text = "Cancel";
            this.btnMenuCancel.UseSelectable = true;
            this.btnMenuCancel.Click += new System.EventHandler(this.btnMenuCancel_Click);
            // 
            // tabMenuControl
            // 
            this.tabMenuControl.Controls.Add(this.tabMainCoursePage);
            this.tabMenuControl.Controls.Add(this.tabDrinksPage);
            this.tabMenuControl.Controls.Add(this.tabDessertPage);
            this.tabMenuControl.Controls.Add(this.tabFavoritesPage);
            this.tabMenuControl.Location = new System.Drawing.Point(-11, -47);
            this.tabMenuControl.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabMenuControl.Name = "tabMenuControl";
            this.tabMenuControl.SelectedIndex = 0;
            this.tabMenuControl.Size = new System.Drawing.Size(1321, 543);
            this.tabMenuControl.Style = MetroFramework.MetroColorStyle.Orange;
            this.tabMenuControl.TabIndex = 2;
            this.tabMenuControl.TabStop = false;
            this.tabMenuControl.UseSelectable = true;
            // 
            // tabMainCoursePage
            // 
            this.tabMainCoursePage.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.tabMainCoursePage.Controls.Add(this.metroTextBox6);
            this.tabMainCoursePage.Controls.Add(this.metroTextBox7);
            this.tabMainCoursePage.Controls.Add(this.metroTextBox8);
            this.tabMainCoursePage.Controls.Add(this.metroTextBox9);
            this.tabMainCoursePage.Controls.Add(this.metroTextBox2);
            this.tabMainCoursePage.Controls.Add(this.metroTextBox5);
            this.tabMainCoursePage.Controls.Add(this.metroTextBox3);
            this.tabMainCoursePage.Controls.Add(this.metroTextBox4);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseEight);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseSeven);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseSix);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseFive);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseFour);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseThree);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseTwo);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseOne);
            this.tabMainCoursePage.HorizontalScrollbarBarColor = true;
            this.tabMainCoursePage.HorizontalScrollbarHighlightOnWheel = false;
            this.tabMainCoursePage.HorizontalScrollbarSize = 12;
            this.tabMainCoursePage.Location = new System.Drawing.Point(4, 38);
            this.tabMainCoursePage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabMainCoursePage.Name = "tabMainCoursePage";
            this.tabMainCoursePage.Size = new System.Drawing.Size(1313, 501);
            this.tabMainCoursePage.TabIndex = 1;
            this.tabMainCoursePage.VerticalScrollbarBarColor = true;
            this.tabMainCoursePage.VerticalScrollbarHighlightOnWheel = false;
            this.tabMainCoursePage.VerticalScrollbarSize = 13;
            // 
            // metroTextBox6
            // 
            this.metroTextBox6.BackColor = System.Drawing.Color.Orange;
            // 
            // 
            // 
            this.metroTextBox6.CustomButton.Image = null;
            this.metroTextBox6.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox6.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox6.CustomButton.Name = "";
            this.metroTextBox6.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox6.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox6.CustomButton.TabIndex = 1;
            this.metroTextBox6.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox6.CustomButton.UseSelectable = true;
            this.metroTextBox6.CustomButton.Visible = false;
            this.metroTextBox6.ForeColor = System.Drawing.Color.Orange;
            this.metroTextBox6.Lines = new string[] {
        "Cheese Burger"};
            this.metroTextBox6.Location = new System.Drawing.Point(1039, 420);
            this.metroTextBox6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox6.MaxLength = 32767;
            this.metroTextBox6.Name = "metroTextBox6";
            this.metroTextBox6.PasswordChar = '\0';
            this.metroTextBox6.ReadOnly = true;
            this.metroTextBox6.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox6.SelectedText = "";
            this.metroTextBox6.SelectionLength = 0;
            this.metroTextBox6.SelectionStart = 0;
            this.metroTextBox6.ShortcutsEnabled = false;
            this.metroTextBox6.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox6.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTextBox6.TabIndex = 26;
            this.metroTextBox6.Text = "Cheese Burger";
            this.metroTextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox6.UseSelectable = true;
            this.metroTextBox6.WaterMarkColor = System.Drawing.Color.Orange;
            this.metroTextBox6.WaterMarkFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // metroTextBox7
            // 
            this.metroTextBox7.BackColor = System.Drawing.Color.Orange;
            // 
            // 
            // 
            this.metroTextBox7.CustomButton.Image = null;
            this.metroTextBox7.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox7.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox7.CustomButton.Name = "";
            this.metroTextBox7.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox7.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox7.CustomButton.TabIndex = 1;
            this.metroTextBox7.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox7.CustomButton.UseSelectable = true;
            this.metroTextBox7.CustomButton.Visible = false;
            this.metroTextBox7.ForeColor = System.Drawing.Color.Orange;
            this.metroTextBox7.Lines = new string[] {
        "Tuna Waffle"};
            this.metroTextBox7.Location = new System.Drawing.Point(37, 420);
            this.metroTextBox7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox7.MaxLength = 32767;
            this.metroTextBox7.Name = "metroTextBox7";
            this.metroTextBox7.PasswordChar = '\0';
            this.metroTextBox7.ReadOnly = true;
            this.metroTextBox7.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox7.SelectedText = "";
            this.metroTextBox7.SelectionLength = 0;
            this.metroTextBox7.SelectionStart = 0;
            this.metroTextBox7.ShortcutsEnabled = false;
            this.metroTextBox7.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox7.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTextBox7.TabIndex = 25;
            this.metroTextBox7.Text = "Tuna Waffle";
            this.metroTextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox7.UseSelectable = true;
            this.metroTextBox7.WaterMarkColor = System.Drawing.Color.Orange;
            this.metroTextBox7.WaterMarkFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // metroTextBox8
            // 
            this.metroTextBox8.BackColor = System.Drawing.Color.Orange;
            // 
            // 
            // 
            this.metroTextBox8.CustomButton.Image = null;
            this.metroTextBox8.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox8.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox8.CustomButton.Name = "";
            this.metroTextBox8.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox8.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox8.CustomButton.TabIndex = 1;
            this.metroTextBox8.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox8.CustomButton.UseSelectable = true;
            this.metroTextBox8.CustomButton.Visible = false;
            this.metroTextBox8.ForeColor = System.Drawing.Color.Orange;
            this.metroTextBox8.Lines = new string[] {
        "Bacon & Cheese Waffle"};
            this.metroTextBox8.Location = new System.Drawing.Point(372, 420);
            this.metroTextBox8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox8.MaxLength = 32767;
            this.metroTextBox8.Name = "metroTextBox8";
            this.metroTextBox8.PasswordChar = '\0';
            this.metroTextBox8.ReadOnly = true;
            this.metroTextBox8.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox8.SelectedText = "";
            this.metroTextBox8.SelectionLength = 0;
            this.metroTextBox8.SelectionStart = 0;
            this.metroTextBox8.ShortcutsEnabled = false;
            this.metroTextBox8.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox8.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTextBox8.TabIndex = 24;
            this.metroTextBox8.Text = "Bacon & Cheese Waffle";
            this.metroTextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox8.UseSelectable = true;
            this.metroTextBox8.WaterMarkColor = System.Drawing.Color.Orange;
            this.metroTextBox8.WaterMarkFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // metroTextBox9
            // 
            this.metroTextBox9.BackColor = System.Drawing.Color.Orange;
            // 
            // 
            // 
            this.metroTextBox9.CustomButton.Image = null;
            this.metroTextBox9.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox9.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox9.CustomButton.Name = "";
            this.metroTextBox9.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox9.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox9.CustomButton.TabIndex = 1;
            this.metroTextBox9.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox9.CustomButton.UseSelectable = true;
            this.metroTextBox9.CustomButton.Visible = false;
            this.metroTextBox9.ForeColor = System.Drawing.Color.Orange;
            this.metroTextBox9.Lines = new string[] {
        "Chicken Burger"};
            this.metroTextBox9.Location = new System.Drawing.Point(707, 420);
            this.metroTextBox9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox9.MaxLength = 32767;
            this.metroTextBox9.Name = "metroTextBox9";
            this.metroTextBox9.PasswordChar = '\0';
            this.metroTextBox9.ReadOnly = true;
            this.metroTextBox9.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox9.SelectedText = "";
            this.metroTextBox9.SelectionLength = 0;
            this.metroTextBox9.SelectionStart = 0;
            this.metroTextBox9.ShortcutsEnabled = false;
            this.metroTextBox9.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox9.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTextBox9.TabIndex = 23;
            this.metroTextBox9.Text = "Chicken Burger";
            this.metroTextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox9.UseSelectable = true;
            this.metroTextBox9.WaterMarkColor = System.Drawing.Color.Orange;
            this.metroTextBox9.WaterMarkFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // metroTextBox2
            // 
            this.metroTextBox2.BackColor = System.Drawing.Color.Orange;
            // 
            // 
            // 
            this.metroTextBox2.CustomButton.Image = null;
            this.metroTextBox2.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox2.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox2.CustomButton.Name = "";
            this.metroTextBox2.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox2.CustomButton.TabIndex = 1;
            this.metroTextBox2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox2.CustomButton.UseSelectable = true;
            this.metroTextBox2.CustomButton.Visible = false;
            this.metroTextBox2.ForeColor = System.Drawing.Color.Orange;
            this.metroTextBox2.Lines = new string[] {
        "Cheese Hotdog"};
            this.metroTextBox2.Location = new System.Drawing.Point(1039, 170);
            this.metroTextBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox2.MaxLength = 32767;
            this.metroTextBox2.Name = "metroTextBox2";
            this.metroTextBox2.PasswordChar = '\0';
            this.metroTextBox2.ReadOnly = true;
            this.metroTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox2.SelectedText = "";
            this.metroTextBox2.SelectionLength = 0;
            this.metroTextBox2.SelectionStart = 0;
            this.metroTextBox2.ShortcutsEnabled = false;
            this.metroTextBox2.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox2.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTextBox2.TabIndex = 22;
            this.metroTextBox2.Text = "Cheese Hotdog";
            this.metroTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox2.UseSelectable = true;
            this.metroTextBox2.WaterMarkColor = System.Drawing.Color.Orange;
            this.metroTextBox2.WaterMarkFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // metroTextBox5
            // 
            this.metroTextBox5.BackColor = System.Drawing.Color.Orange;
            // 
            // 
            // 
            this.metroTextBox5.CustomButton.Image = null;
            this.metroTextBox5.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox5.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox5.CustomButton.Name = "";
            this.metroTextBox5.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox5.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox5.CustomButton.TabIndex = 1;
            this.metroTextBox5.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox5.CustomButton.UseSelectable = true;
            this.metroTextBox5.CustomButton.Visible = false;
            this.metroTextBox5.ForeColor = System.Drawing.Color.Orange;
            this.metroTextBox5.Lines = new string[] {
        "Tuna Sandwich"};
            this.metroTextBox5.Location = new System.Drawing.Point(37, 170);
            this.metroTextBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox5.MaxLength = 32767;
            this.metroTextBox5.Name = "metroTextBox5";
            this.metroTextBox5.PasswordChar = '\0';
            this.metroTextBox5.ReadOnly = true;
            this.metroTextBox5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox5.SelectedText = "";
            this.metroTextBox5.SelectionLength = 0;
            this.metroTextBox5.SelectionStart = 0;
            this.metroTextBox5.ShortcutsEnabled = false;
            this.metroTextBox5.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox5.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTextBox5.TabIndex = 21;
            this.metroTextBox5.Text = "Tuna Sandwich";
            this.metroTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox5.UseSelectable = true;
            this.metroTextBox5.WaterMarkColor = System.Drawing.Color.Orange;
            this.metroTextBox5.WaterMarkFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // metroTextBox3
            // 
            this.metroTextBox3.BackColor = System.Drawing.Color.Orange;
            // 
            // 
            // 
            this.metroTextBox3.CustomButton.Image = null;
            this.metroTextBox3.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox3.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox3.CustomButton.Name = "";
            this.metroTextBox3.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox3.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox3.CustomButton.TabIndex = 1;
            this.metroTextBox3.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox3.CustomButton.UseSelectable = true;
            this.metroTextBox3.CustomButton.Visible = false;
            this.metroTextBox3.ForeColor = System.Drawing.Color.Orange;
            this.metroTextBox3.Lines = new string[] {
        "Chicken Sandwich"};
            this.metroTextBox3.Location = new System.Drawing.Point(372, 170);
            this.metroTextBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox3.MaxLength = 32767;
            this.metroTextBox3.Name = "metroTextBox3";
            this.metroTextBox3.PasswordChar = '\0';
            this.metroTextBox3.ReadOnly = true;
            this.metroTextBox3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox3.SelectedText = "";
            this.metroTextBox3.SelectionLength = 0;
            this.metroTextBox3.SelectionStart = 0;
            this.metroTextBox3.ShortcutsEnabled = false;
            this.metroTextBox3.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox3.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTextBox3.TabIndex = 20;
            this.metroTextBox3.Text = "Chicken Sandwich";
            this.metroTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox3.UseSelectable = true;
            this.metroTextBox3.WaterMarkColor = System.Drawing.Color.Orange;
            this.metroTextBox3.WaterMarkFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // metroTextBox4
            // 
            this.metroTextBox4.BackColor = System.Drawing.Color.Orange;
            // 
            // 
            // 
            this.metroTextBox4.CustomButton.Image = null;
            this.metroTextBox4.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox4.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox4.CustomButton.Name = "";
            this.metroTextBox4.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox4.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox4.CustomButton.TabIndex = 1;
            this.metroTextBox4.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox4.CustomButton.UseSelectable = true;
            this.metroTextBox4.CustomButton.Visible = false;
            this.metroTextBox4.ForeColor = System.Drawing.Color.Orange;
            this.metroTextBox4.Lines = new string[] {
        "Chicken Hotdog"};
            this.metroTextBox4.Location = new System.Drawing.Point(707, 170);
            this.metroTextBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox4.MaxLength = 32767;
            this.metroTextBox4.Name = "metroTextBox4";
            this.metroTextBox4.PasswordChar = '\0';
            this.metroTextBox4.ReadOnly = true;
            this.metroTextBox4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox4.SelectedText = "";
            this.metroTextBox4.SelectionLength = 0;
            this.metroTextBox4.SelectionStart = 0;
            this.metroTextBox4.ShortcutsEnabled = false;
            this.metroTextBox4.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox4.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTextBox4.TabIndex = 19;
            this.metroTextBox4.Text = "Chicken Hotdog";
            this.metroTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox4.UseSelectable = true;
            this.metroTextBox4.WaterMarkColor = System.Drawing.Color.Orange;
            this.metroTextBox4.WaterMarkFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnMenuMainCourseEight
            // 
            this.btnMenuMainCourseEight.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Cheese_Burger;
            this.btnMenuMainCourseEight.Location = new System.Drawing.Point(1023, 271);
            this.btnMenuMainCourseEight.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseEight.Name = "btnMenuMainCourseEight";
            this.btnMenuMainCourseEight.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseEight.TabIndex = 16;
            this.btnMenuMainCourseEight.UseSelectable = true;
            this.btnMenuMainCourseEight.Click += new System.EventHandler(this.btnMenuMainCourseEight_Click);
            // 
            // btnMenuMainCourseSeven
            // 
            this.btnMenuMainCourseSeven.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Chicken_Burger;
            this.btnMenuMainCourseSeven.Location = new System.Drawing.Point(689, 271);
            this.btnMenuMainCourseSeven.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseSeven.Name = "btnMenuMainCourseSeven";
            this.btnMenuMainCourseSeven.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseSeven.TabIndex = 15;
            this.btnMenuMainCourseSeven.UseSelectable = true;
            this.btnMenuMainCourseSeven.Click += new System.EventHandler(this.btnMenuMainCourseSeven_Click);
            // 
            // btnMenuMainCourseSix
            // 
            this.btnMenuMainCourseSix.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Bacon___Cheese_Waffle;
            this.btnMenuMainCourseSix.Location = new System.Drawing.Point(355, 271);
            this.btnMenuMainCourseSix.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseSix.Name = "btnMenuMainCourseSix";
            this.btnMenuMainCourseSix.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseSix.TabIndex = 14;
            this.btnMenuMainCourseSix.UseSelectable = true;
            this.btnMenuMainCourseSix.Click += new System.EventHandler(this.btnMenuMainCourseSix_Click);
            // 
            // btnMenuMainCourseFive
            // 
            this.btnMenuMainCourseFive.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Tuna_Waffle;
            this.btnMenuMainCourseFive.Location = new System.Drawing.Point(20, 271);
            this.btnMenuMainCourseFive.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseFive.Name = "btnMenuMainCourseFive";
            this.btnMenuMainCourseFive.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseFive.TabIndex = 13;
            this.btnMenuMainCourseFive.UseSelectable = true;
            this.btnMenuMainCourseFive.Click += new System.EventHandler(this.btnMenuMainCourseFive_Click);
            // 
            // btnMenuMainCourseFour
            // 
            this.btnMenuMainCourseFour.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Cheese_Hotdog;
            this.btnMenuMainCourseFour.Location = new System.Drawing.Point(1023, 22);
            this.btnMenuMainCourseFour.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseFour.Name = "btnMenuMainCourseFour";
            this.btnMenuMainCourseFour.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseFour.TabIndex = 8;
            this.btnMenuMainCourseFour.UseSelectable = true;
            this.btnMenuMainCourseFour.Click += new System.EventHandler(this.btnMenuMainCourseFour_Click);
            // 
            // btnMenuMainCourseThree
            // 
            this.btnMenuMainCourseThree.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Hotdog;
            this.btnMenuMainCourseThree.Location = new System.Drawing.Point(689, 22);
            this.btnMenuMainCourseThree.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseThree.Name = "btnMenuMainCourseThree";
            this.btnMenuMainCourseThree.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseThree.TabIndex = 7;
            this.btnMenuMainCourseThree.UseSelectable = true;
            this.btnMenuMainCourseThree.Click += new System.EventHandler(this.btnMenuMainCourseThree_Click);
            // 
            // btnMenuMainCourseTwo
            // 
            this.btnMenuMainCourseTwo.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Chicken_Sandwich;
            this.btnMenuMainCourseTwo.Location = new System.Drawing.Point(355, 22);
            this.btnMenuMainCourseTwo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseTwo.Name = "btnMenuMainCourseTwo";
            this.btnMenuMainCourseTwo.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseTwo.TabIndex = 6;
            this.btnMenuMainCourseTwo.UseSelectable = true;
            this.btnMenuMainCourseTwo.Click += new System.EventHandler(this.btnMenuMainCourseTwo_Click);
            // 
            // btnMenuMainCourseOne
            // 
            this.btnMenuMainCourseOne.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Tuna_Sandwich;
            this.btnMenuMainCourseOne.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnMenuMainCourseOne.Location = new System.Drawing.Point(20, 22);
            this.btnMenuMainCourseOne.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseOne.Name = "btnMenuMainCourseOne";
            this.btnMenuMainCourseOne.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseOne.TabIndex = 5;
            this.btnMenuMainCourseOne.UseSelectable = true;
            this.btnMenuMainCourseOne.Click += new System.EventHandler(this.btnMenuMainCourseOne_Click);
            // 
            // tabDrinksPage
            // 
            this.tabDrinksPage.Controls.Add(this.metroTextBox14);
            this.tabDrinksPage.Controls.Add(this.metroTextBox15);
            this.tabDrinksPage.Controls.Add(this.metroTextBox10);
            this.tabDrinksPage.Controls.Add(this.metroTextBox11);
            this.tabDrinksPage.Controls.Add(this.metroTextBox12);
            this.tabDrinksPage.Controls.Add(this.metroTextBox13);
            this.tabDrinksPage.Controls.Add(this.btnMenuDrinksSeven);
            this.tabDrinksPage.Controls.Add(this.btnMenuDrinksFive);
            this.tabDrinksPage.Controls.Add(this.btnMenuDrinksFour);
            this.tabDrinksPage.Controls.Add(this.btnMenuDrinksThree);
            this.tabDrinksPage.Controls.Add(this.btnMenuDrinksTwo);
            this.tabDrinksPage.Controls.Add(this.btnMenuDrinksOne);
            this.tabDrinksPage.HorizontalScrollbarBarColor = true;
            this.tabDrinksPage.HorizontalScrollbarHighlightOnWheel = false;
            this.tabDrinksPage.HorizontalScrollbarSize = 12;
            this.tabDrinksPage.Location = new System.Drawing.Point(4, 38);
            this.tabDrinksPage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabDrinksPage.Name = "tabDrinksPage";
            this.tabDrinksPage.Size = new System.Drawing.Size(1313, 501);
            this.tabDrinksPage.TabIndex = 2;
            this.tabDrinksPage.VerticalScrollbarBarColor = true;
            this.tabDrinksPage.VerticalScrollbarHighlightOnWheel = false;
            this.tabDrinksPage.VerticalScrollbarSize = 13;
            // 
            // metroTextBox14
            // 
            // 
            // 
            // 
            this.metroTextBox14.CustomButton.Image = null;
            this.metroTextBox14.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox14.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox14.CustomButton.Name = "";
            this.metroTextBox14.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox14.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox14.CustomButton.TabIndex = 1;
            this.metroTextBox14.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox14.CustomButton.UseSelectable = true;
            this.metroTextBox14.CustomButton.Visible = false;
            this.metroTextBox14.Lines = new string[] {
        "Pineapple Juice"};
            this.metroTextBox14.Location = new System.Drawing.Point(37, 420);
            this.metroTextBox14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox14.MaxLength = 32767;
            this.metroTextBox14.Name = "metroTextBox14";
            this.metroTextBox14.PasswordChar = '\0';
            this.metroTextBox14.ReadOnly = true;
            this.metroTextBox14.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox14.SelectedText = "";
            this.metroTextBox14.SelectionLength = 0;
            this.metroTextBox14.SelectionStart = 0;
            this.metroTextBox14.ShortcutsEnabled = true;
            this.metroTextBox14.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox14.TabIndex = 28;
            this.metroTextBox14.Text = "Pineapple Juice";
            this.metroTextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox14.UseSelectable = true;
            this.metroTextBox14.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox14.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox15
            // 
            // 
            // 
            // 
            this.metroTextBox15.CustomButton.Image = null;
            this.metroTextBox15.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox15.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox15.CustomButton.Name = "";
            this.metroTextBox15.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox15.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox15.CustomButton.TabIndex = 1;
            this.metroTextBox15.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox15.CustomButton.UseSelectable = true;
            this.metroTextBox15.CustomButton.Visible = false;
            this.metroTextBox15.Lines = new string[] {
        "Orange Juice"};
            this.metroTextBox15.Location = new System.Drawing.Point(372, 420);
            this.metroTextBox15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox15.MaxLength = 32767;
            this.metroTextBox15.Name = "metroTextBox15";
            this.metroTextBox15.PasswordChar = '\0';
            this.metroTextBox15.ReadOnly = true;
            this.metroTextBox15.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox15.SelectedText = "";
            this.metroTextBox15.SelectionLength = 0;
            this.metroTextBox15.SelectionStart = 0;
            this.metroTextBox15.ShortcutsEnabled = true;
            this.metroTextBox15.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox15.TabIndex = 27;
            this.metroTextBox15.Text = "Orange Juice";
            this.metroTextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox15.UseSelectable = true;
            this.metroTextBox15.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox15.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox10
            // 
            // 
            // 
            // 
            this.metroTextBox10.CustomButton.Image = null;
            this.metroTextBox10.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox10.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox10.CustomButton.Name = "";
            this.metroTextBox10.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox10.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox10.CustomButton.TabIndex = 1;
            this.metroTextBox10.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox10.CustomButton.UseSelectable = true;
            this.metroTextBox10.CustomButton.Visible = false;
            this.metroTextBox10.Lines = new string[] {
        "Mountain Dew"};
            this.metroTextBox10.Location = new System.Drawing.Point(1039, 170);
            this.metroTextBox10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox10.MaxLength = 32767;
            this.metroTextBox10.Name = "metroTextBox10";
            this.metroTextBox10.PasswordChar = '\0';
            this.metroTextBox10.ReadOnly = true;
            this.metroTextBox10.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox10.SelectedText = "";
            this.metroTextBox10.SelectionLength = 0;
            this.metroTextBox10.SelectionStart = 0;
            this.metroTextBox10.ShortcutsEnabled = true;
            this.metroTextBox10.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox10.TabIndex = 26;
            this.metroTextBox10.Text = "Mountain Dew";
            this.metroTextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox10.UseSelectable = true;
            this.metroTextBox10.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox10.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox11
            // 
            // 
            // 
            // 
            this.metroTextBox11.CustomButton.Image = null;
            this.metroTextBox11.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox11.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox11.CustomButton.Name = "";
            this.metroTextBox11.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox11.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox11.CustomButton.TabIndex = 1;
            this.metroTextBox11.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox11.CustomButton.UseSelectable = true;
            this.metroTextBox11.CustomButton.Visible = false;
            this.metroTextBox11.Lines = new string[] {
        "Coke"};
            this.metroTextBox11.Location = new System.Drawing.Point(37, 170);
            this.metroTextBox11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox11.MaxLength = 32767;
            this.metroTextBox11.Name = "metroTextBox11";
            this.metroTextBox11.PasswordChar = '\0';
            this.metroTextBox11.ReadOnly = true;
            this.metroTextBox11.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox11.SelectedText = "";
            this.metroTextBox11.SelectionLength = 0;
            this.metroTextBox11.SelectionStart = 0;
            this.metroTextBox11.ShortcutsEnabled = true;
            this.metroTextBox11.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox11.TabIndex = 25;
            this.metroTextBox11.Text = "Coke";
            this.metroTextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox11.UseSelectable = true;
            this.metroTextBox11.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox11.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox12
            // 
            // 
            // 
            // 
            this.metroTextBox12.CustomButton.Image = null;
            this.metroTextBox12.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox12.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox12.CustomButton.Name = "";
            this.metroTextBox12.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox12.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox12.CustomButton.TabIndex = 1;
            this.metroTextBox12.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox12.CustomButton.UseSelectable = true;
            this.metroTextBox12.CustomButton.Visible = false;
            this.metroTextBox12.Lines = new string[] {
        "Sprite"};
            this.metroTextBox12.Location = new System.Drawing.Point(372, 170);
            this.metroTextBox12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox12.MaxLength = 32767;
            this.metroTextBox12.Name = "metroTextBox12";
            this.metroTextBox12.PasswordChar = '\0';
            this.metroTextBox12.ReadOnly = true;
            this.metroTextBox12.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox12.SelectedText = "";
            this.metroTextBox12.SelectionLength = 0;
            this.metroTextBox12.SelectionStart = 0;
            this.metroTextBox12.ShortcutsEnabled = true;
            this.metroTextBox12.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox12.TabIndex = 24;
            this.metroTextBox12.Text = "Sprite";
            this.metroTextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox12.UseSelectable = true;
            this.metroTextBox12.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox12.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox13
            // 
            // 
            // 
            // 
            this.metroTextBox13.CustomButton.Image = null;
            this.metroTextBox13.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox13.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox13.CustomButton.Name = "";
            this.metroTextBox13.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox13.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox13.CustomButton.TabIndex = 1;
            this.metroTextBox13.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox13.CustomButton.UseSelectable = true;
            this.metroTextBox13.CustomButton.Visible = false;
            this.metroTextBox13.Lines = new string[] {
        "Fanta"};
            this.metroTextBox13.Location = new System.Drawing.Point(707, 170);
            this.metroTextBox13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox13.MaxLength = 32767;
            this.metroTextBox13.Name = "metroTextBox13";
            this.metroTextBox13.PasswordChar = '\0';
            this.metroTextBox13.ReadOnly = true;
            this.metroTextBox13.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox13.SelectedText = "";
            this.metroTextBox13.SelectionLength = 0;
            this.metroTextBox13.SelectionStart = 0;
            this.metroTextBox13.ShortcutsEnabled = true;
            this.metroTextBox13.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox13.TabIndex = 23;
            this.metroTextBox13.Text = "Fanta";
            this.metroTextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox13.UseSelectable = true;
            this.metroTextBox13.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox13.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnMenuDrinksSeven
            // 
            this.btnMenuDrinksSeven.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Orange_Juice;
            this.btnMenuDrinksSeven.Location = new System.Drawing.Point(355, 271);
            this.btnMenuDrinksSeven.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinksSeven.Name = "btnMenuDrinksSeven";
            this.btnMenuDrinksSeven.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDrinksSeven.TabIndex = 18;
            this.btnMenuDrinksSeven.UseSelectable = true;
            this.btnMenuDrinksSeven.Click += new System.EventHandler(this.btnMenuDrinksSeven_Click);
            // 
            // btnMenuDrinksFive
            // 
            this.btnMenuDrinksFive.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Pineapple_Juice;
            this.btnMenuDrinksFive.Location = new System.Drawing.Point(20, 271);
            this.btnMenuDrinksFive.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinksFive.Name = "btnMenuDrinksFive";
            this.btnMenuDrinksFive.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDrinksFive.TabIndex = 17;
            this.btnMenuDrinksFive.UseSelectable = true;
            this.btnMenuDrinksFive.Click += new System.EventHandler(this.btnMenuDrinksFive_Click);
            // 
            // btnMenuDrinksFour
            // 
            this.btnMenuDrinksFour.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Mountain_Dew;
            this.btnMenuDrinksFour.Location = new System.Drawing.Point(1023, 22);
            this.btnMenuDrinksFour.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinksFour.Name = "btnMenuDrinksFour";
            this.btnMenuDrinksFour.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDrinksFour.TabIndex = 16;
            this.btnMenuDrinksFour.UseSelectable = true;
            this.btnMenuDrinksFour.Click += new System.EventHandler(this.btnMenuDrinksFour_Click);
            // 
            // btnMenuDrinksThree
            // 
            this.btnMenuDrinksThree.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Fanta;
            this.btnMenuDrinksThree.Location = new System.Drawing.Point(689, 22);
            this.btnMenuDrinksThree.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinksThree.Name = "btnMenuDrinksThree";
            this.btnMenuDrinksThree.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDrinksThree.TabIndex = 15;
            this.btnMenuDrinksThree.UseSelectable = true;
            this.btnMenuDrinksThree.Click += new System.EventHandler(this.btnMenuDrinksThree_Click);
            // 
            // btnMenuDrinksTwo
            // 
            this.btnMenuDrinksTwo.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Sprite;
            this.btnMenuDrinksTwo.Location = new System.Drawing.Point(355, 22);
            this.btnMenuDrinksTwo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinksTwo.Name = "btnMenuDrinksTwo";
            this.btnMenuDrinksTwo.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDrinksTwo.TabIndex = 14;
            this.btnMenuDrinksTwo.UseSelectable = true;
            this.btnMenuDrinksTwo.Click += new System.EventHandler(this.btnMenuDrinksTwo_Click);
            // 
            // btnMenuDrinksOne
            // 
            this.btnMenuDrinksOne.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Coke;
            this.btnMenuDrinksOne.Location = new System.Drawing.Point(20, 22);
            this.btnMenuDrinksOne.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinksOne.Name = "btnMenuDrinksOne";
            this.btnMenuDrinksOne.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDrinksOne.TabIndex = 13;
            this.btnMenuDrinksOne.UseSelectable = true;
            this.btnMenuDrinksOne.Click += new System.EventHandler(this.btnMenuDrinksOne_Click);
            // 
            // tabDessertPage
            // 
            this.tabDessertPage.Controls.Add(this.metroTextBox16);
            this.tabDessertPage.Controls.Add(this.metroTextBox17);
            this.tabDessertPage.Controls.Add(this.metroTextBox18);
            this.tabDessertPage.Controls.Add(this.metroTextBox19);
            this.tabDessertPage.Controls.Add(this.btnMenuDessertFour);
            this.tabDessertPage.Controls.Add(this.btnMenuDessertThree);
            this.tabDessertPage.Controls.Add(this.btnMenuDessertTwo);
            this.tabDessertPage.Controls.Add(this.btnMenuDessertOne);
            this.tabDessertPage.HorizontalScrollbarBarColor = true;
            this.tabDessertPage.HorizontalScrollbarHighlightOnWheel = false;
            this.tabDessertPage.HorizontalScrollbarSize = 12;
            this.tabDessertPage.Location = new System.Drawing.Point(4, 38);
            this.tabDessertPage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabDessertPage.Name = "tabDessertPage";
            this.tabDessertPage.Size = new System.Drawing.Size(1313, 501);
            this.tabDessertPage.TabIndex = 3;
            this.tabDessertPage.VerticalScrollbarBarColor = true;
            this.tabDessertPage.VerticalScrollbarHighlightOnWheel = false;
            this.tabDessertPage.VerticalScrollbarSize = 13;
            // 
            // metroTextBox16
            // 
            // 
            // 
            // 
            this.metroTextBox16.CustomButton.Image = null;
            this.metroTextBox16.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox16.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox16.CustomButton.Name = "";
            this.metroTextBox16.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox16.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox16.CustomButton.TabIndex = 1;
            this.metroTextBox16.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox16.CustomButton.UseSelectable = true;
            this.metroTextBox16.CustomButton.Visible = false;
            this.metroTextBox16.Lines = new string[] {
        "Churro Donut"};
            this.metroTextBox16.Location = new System.Drawing.Point(1039, 170);
            this.metroTextBox16.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox16.MaxLength = 32767;
            this.metroTextBox16.Name = "metroTextBox16";
            this.metroTextBox16.PasswordChar = '\0';
            this.metroTextBox16.ReadOnly = true;
            this.metroTextBox16.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox16.SelectedText = "";
            this.metroTextBox16.SelectionLength = 0;
            this.metroTextBox16.SelectionStart = 0;
            this.metroTextBox16.ShortcutsEnabled = true;
            this.metroTextBox16.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox16.TabIndex = 30;
            this.metroTextBox16.Text = "Churro Donut";
            this.metroTextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox16.UseSelectable = true;
            this.metroTextBox16.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox16.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox17
            // 
            // 
            // 
            // 
            this.metroTextBox17.CustomButton.Image = null;
            this.metroTextBox17.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox17.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox17.CustomButton.Name = "";
            this.metroTextBox17.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox17.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox17.CustomButton.TabIndex = 1;
            this.metroTextBox17.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox17.CustomButton.UseSelectable = true;
            this.metroTextBox17.CustomButton.Visible = false;
            this.metroTextBox17.Lines = new string[] {
        "Halo-Halo"};
            this.metroTextBox17.Location = new System.Drawing.Point(37, 170);
            this.metroTextBox17.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox17.MaxLength = 32767;
            this.metroTextBox17.Name = "metroTextBox17";
            this.metroTextBox17.PasswordChar = '\0';
            this.metroTextBox17.ReadOnly = true;
            this.metroTextBox17.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox17.SelectedText = "";
            this.metroTextBox17.SelectionLength = 0;
            this.metroTextBox17.SelectionStart = 0;
            this.metroTextBox17.ShortcutsEnabled = true;
            this.metroTextBox17.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox17.TabIndex = 29;
            this.metroTextBox17.Text = "Halo-Halo";
            this.metroTextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox17.UseSelectable = true;
            this.metroTextBox17.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox17.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox18
            // 
            // 
            // 
            // 
            this.metroTextBox18.CustomButton.Image = null;
            this.metroTextBox18.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox18.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox18.CustomButton.Name = "";
            this.metroTextBox18.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox18.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox18.CustomButton.TabIndex = 1;
            this.metroTextBox18.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox18.CustomButton.UseSelectable = true;
            this.metroTextBox18.CustomButton.Visible = false;
            this.metroTextBox18.Lines = new string[] {
        "Leche Flan"};
            this.metroTextBox18.Location = new System.Drawing.Point(372, 170);
            this.metroTextBox18.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox18.MaxLength = 32767;
            this.metroTextBox18.Name = "metroTextBox18";
            this.metroTextBox18.PasswordChar = '\0';
            this.metroTextBox18.ReadOnly = true;
            this.metroTextBox18.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox18.SelectedText = "";
            this.metroTextBox18.SelectionLength = 0;
            this.metroTextBox18.SelectionStart = 0;
            this.metroTextBox18.ShortcutsEnabled = true;
            this.metroTextBox18.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox18.TabIndex = 28;
            this.metroTextBox18.Text = "Leche Flan";
            this.metroTextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox18.UseSelectable = true;
            this.metroTextBox18.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox18.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox19
            // 
            // 
            // 
            // 
            this.metroTextBox19.CustomButton.Image = null;
            this.metroTextBox19.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox19.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox19.CustomButton.Name = "";
            this.metroTextBox19.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox19.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox19.CustomButton.TabIndex = 1;
            this.metroTextBox19.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox19.CustomButton.UseSelectable = true;
            this.metroTextBox19.CustomButton.Visible = false;
            this.metroTextBox19.Lines = new string[] {
        "Ube Cheese Pie"};
            this.metroTextBox19.Location = new System.Drawing.Point(707, 170);
            this.metroTextBox19.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox19.MaxLength = 32767;
            this.metroTextBox19.Name = "metroTextBox19";
            this.metroTextBox19.PasswordChar = '\0';
            this.metroTextBox19.ReadOnly = true;
            this.metroTextBox19.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox19.SelectedText = "";
            this.metroTextBox19.SelectionLength = 0;
            this.metroTextBox19.SelectionStart = 0;
            this.metroTextBox19.ShortcutsEnabled = true;
            this.metroTextBox19.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox19.TabIndex = 27;
            this.metroTextBox19.Text = "Ube Cheese Pie";
            this.metroTextBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox19.UseSelectable = true;
            this.metroTextBox19.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox19.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnMenuDessertFour
            // 
            this.btnMenuDessertFour.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Churro_Donut;
            this.btnMenuDessertFour.Location = new System.Drawing.Point(1023, 22);
            this.btnMenuDessertFour.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDessertFour.Name = "btnMenuDessertFour";
            this.btnMenuDessertFour.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDessertFour.TabIndex = 22;
            this.btnMenuDessertFour.UseSelectable = true;
            this.btnMenuDessertFour.Click += new System.EventHandler(this.btnMenuDessertFour_Click);
            // 
            // btnMenuDessertThree
            // 
            this.btnMenuDessertThree.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Ube_Cheese_Pie;
            this.btnMenuDessertThree.Location = new System.Drawing.Point(689, 22);
            this.btnMenuDessertThree.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDessertThree.Name = "btnMenuDessertThree";
            this.btnMenuDessertThree.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDessertThree.TabIndex = 21;
            this.btnMenuDessertThree.Tag = "";
            this.btnMenuDessertThree.UseSelectable = true;
            this.btnMenuDessertThree.Click += new System.EventHandler(this.btnMenuDessertThree_Click);
            // 
            // btnMenuDessertTwo
            // 
            this.btnMenuDessertTwo.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Leche_Flan;
            this.btnMenuDessertTwo.Location = new System.Drawing.Point(355, 22);
            this.btnMenuDessertTwo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDessertTwo.Name = "btnMenuDessertTwo";
            this.btnMenuDessertTwo.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDessertTwo.TabIndex = 20;
            this.btnMenuDessertTwo.UseSelectable = true;
            this.btnMenuDessertTwo.Click += new System.EventHandler(this.btnMenuDessertTwo_Click);
            // 
            // btnMenuDessertOne
            // 
            this.btnMenuDessertOne.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Halo_Halo;
            this.btnMenuDessertOne.Location = new System.Drawing.Point(20, 22);
            this.btnMenuDessertOne.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDessertOne.Name = "btnMenuDessertOne";
            this.btnMenuDessertOne.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDessertOne.TabIndex = 19;
            this.btnMenuDessertOne.UseSelectable = true;
            this.btnMenuDessertOne.Click += new System.EventHandler(this.btnMenuDessertOne_Click);
            // 
            // tabFavoritesPage
            // 
            this.tabFavoritesPage.Controls.Add(this.metroTextBox24);
            this.tabFavoritesPage.Controls.Add(this.metroTextBox20);
            this.tabFavoritesPage.Controls.Add(this.metroTextBox21);
            this.tabFavoritesPage.Controls.Add(this.metroTextBox22);
            this.tabFavoritesPage.Controls.Add(this.metroTextBox23);
            this.tabFavoritesPage.Controls.Add(this.btnMenuFavoritesFive);
            this.tabFavoritesPage.Controls.Add(this.btnMenuFavoritesFour);
            this.tabFavoritesPage.Controls.Add(this.btnMenuFavoritesThree);
            this.tabFavoritesPage.Controls.Add(this.btnMenuFavoritesTwo);
            this.tabFavoritesPage.Controls.Add(this.btnMenuFavoritesOne);
            this.tabFavoritesPage.HorizontalScrollbarBarColor = true;
            this.tabFavoritesPage.HorizontalScrollbarHighlightOnWheel = false;
            this.tabFavoritesPage.HorizontalScrollbarSize = 12;
            this.tabFavoritesPage.Location = new System.Drawing.Point(4, 38);
            this.tabFavoritesPage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabFavoritesPage.Name = "tabFavoritesPage";
            this.tabFavoritesPage.Size = new System.Drawing.Size(1313, 501);
            this.tabFavoritesPage.TabIndex = 4;
            this.tabFavoritesPage.VerticalScrollbarBarColor = true;
            this.tabFavoritesPage.VerticalScrollbarHighlightOnWheel = false;
            this.tabFavoritesPage.VerticalScrollbarSize = 13;
            // 
            // metroTextBox24
            // 
            // 
            // 
            // 
            this.metroTextBox24.CustomButton.Image = null;
            this.metroTextBox24.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox24.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox24.CustomButton.Name = "";
            this.metroTextBox24.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox24.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox24.CustomButton.TabIndex = 1;
            this.metroTextBox24.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox24.CustomButton.UseSelectable = true;
            this.metroTextBox24.CustomButton.Visible = false;
            this.metroTextBox24.Lines = new string[] {
        "Ube Cheese Pie"};
            this.metroTextBox24.Location = new System.Drawing.Point(37, 420);
            this.metroTextBox24.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox24.MaxLength = 32767;
            this.metroTextBox24.Name = "metroTextBox24";
            this.metroTextBox24.PasswordChar = '\0';
            this.metroTextBox24.ReadOnly = true;
            this.metroTextBox24.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox24.SelectedText = "";
            this.metroTextBox24.SelectionLength = 0;
            this.metroTextBox24.SelectionStart = 0;
            this.metroTextBox24.ShortcutsEnabled = true;
            this.metroTextBox24.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox24.TabIndex = 35;
            this.metroTextBox24.Text = "Ube Cheese Pie";
            this.metroTextBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox24.UseSelectable = true;
            this.metroTextBox24.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox24.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox20
            // 
            // 
            // 
            // 
            this.metroTextBox20.CustomButton.Image = null;
            this.metroTextBox20.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox20.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox20.CustomButton.Name = "";
            this.metroTextBox20.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox20.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox20.CustomButton.TabIndex = 1;
            this.metroTextBox20.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox20.CustomButton.UseSelectable = true;
            this.metroTextBox20.CustomButton.Visible = false;
            this.metroTextBox20.Lines = new string[] {
        "Halo-Halo"};
            this.metroTextBox20.Location = new System.Drawing.Point(1039, 170);
            this.metroTextBox20.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox20.MaxLength = 32767;
            this.metroTextBox20.Name = "metroTextBox20";
            this.metroTextBox20.PasswordChar = '\0';
            this.metroTextBox20.ReadOnly = true;
            this.metroTextBox20.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox20.SelectedText = "";
            this.metroTextBox20.SelectionLength = 0;
            this.metroTextBox20.SelectionStart = 0;
            this.metroTextBox20.ShortcutsEnabled = true;
            this.metroTextBox20.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox20.TabIndex = 34;
            this.metroTextBox20.Text = "Halo-Halo";
            this.metroTextBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox20.UseSelectable = true;
            this.metroTextBox20.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox20.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox21
            // 
            // 
            // 
            // 
            this.metroTextBox21.CustomButton.Image = null;
            this.metroTextBox21.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox21.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox21.CustomButton.Name = "";
            this.metroTextBox21.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox21.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox21.CustomButton.TabIndex = 1;
            this.metroTextBox21.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox21.CustomButton.UseSelectable = true;
            this.metroTextBox21.CustomButton.Visible = false;
            this.metroTextBox21.Lines = new string[] {
        "Chicken Sandwich"};
            this.metroTextBox21.Location = new System.Drawing.Point(37, 170);
            this.metroTextBox21.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox21.MaxLength = 32767;
            this.metroTextBox21.Name = "metroTextBox21";
            this.metroTextBox21.PasswordChar = '\0';
            this.metroTextBox21.ReadOnly = true;
            this.metroTextBox21.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox21.SelectedText = "";
            this.metroTextBox21.SelectionLength = 0;
            this.metroTextBox21.SelectionStart = 0;
            this.metroTextBox21.ShortcutsEnabled = true;
            this.metroTextBox21.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox21.TabIndex = 33;
            this.metroTextBox21.Text = "Chicken Sandwich";
            this.metroTextBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox21.UseSelectable = true;
            this.metroTextBox21.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox21.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox22
            // 
            // 
            // 
            // 
            this.metroTextBox22.CustomButton.Image = null;
            this.metroTextBox22.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox22.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox22.CustomButton.Name = "";
            this.metroTextBox22.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox22.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox22.CustomButton.TabIndex = 1;
            this.metroTextBox22.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox22.CustomButton.UseSelectable = true;
            this.metroTextBox22.CustomButton.Visible = false;
            this.metroTextBox22.Lines = new string[] {
        "Cheese Hotdog"};
            this.metroTextBox22.Location = new System.Drawing.Point(372, 170);
            this.metroTextBox22.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox22.MaxLength = 32767;
            this.metroTextBox22.Name = "metroTextBox22";
            this.metroTextBox22.PasswordChar = '\0';
            this.metroTextBox22.ReadOnly = true;
            this.metroTextBox22.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox22.SelectedText = "";
            this.metroTextBox22.SelectionLength = 0;
            this.metroTextBox22.SelectionStart = 0;
            this.metroTextBox22.ShortcutsEnabled = true;
            this.metroTextBox22.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox22.TabIndex = 32;
            this.metroTextBox22.Text = "Cheese Hotdog";
            this.metroTextBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox22.UseSelectable = true;
            this.metroTextBox22.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox22.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox23
            // 
            // 
            // 
            // 
            this.metroTextBox23.CustomButton.Image = null;
            this.metroTextBox23.CustomButton.Location = new System.Drawing.Point(279, 2);
            this.metroTextBox23.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.metroTextBox23.CustomButton.Name = "";
            this.metroTextBox23.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.metroTextBox23.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox23.CustomButton.TabIndex = 1;
            this.metroTextBox23.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox23.CustomButton.UseSelectable = true;
            this.metroTextBox23.CustomButton.Visible = false;
            this.metroTextBox23.Lines = new string[] {
        "Bacon  & Cheese Waffle"};
            this.metroTextBox23.Location = new System.Drawing.Point(707, 170);
            this.metroTextBox23.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTextBox23.MaxLength = 32767;
            this.metroTextBox23.Name = "metroTextBox23";
            this.metroTextBox23.PasswordChar = '\0';
            this.metroTextBox23.ReadOnly = true;
            this.metroTextBox23.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox23.SelectedText = "";
            this.metroTextBox23.SelectionLength = 0;
            this.metroTextBox23.SelectionStart = 0;
            this.metroTextBox23.ShortcutsEnabled = true;
            this.metroTextBox23.Size = new System.Drawing.Size(235, 28);
            this.metroTextBox23.TabIndex = 31;
            this.metroTextBox23.Text = "Bacon  & Cheese Waffle";
            this.metroTextBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox23.UseSelectable = true;
            this.metroTextBox23.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox23.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnMenuFavoritesFive
            // 
            this.btnMenuFavoritesFive.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Ube_Cheese_Pie;
            this.btnMenuFavoritesFive.Location = new System.Drawing.Point(20, 271);
            this.btnMenuFavoritesFive.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuFavoritesFive.Name = "btnMenuFavoritesFive";
            this.btnMenuFavoritesFive.Size = new System.Drawing.Size(267, 190);
            this.btnMenuFavoritesFive.TabIndex = 27;
            this.btnMenuFavoritesFive.UseSelectable = true;
            this.btnMenuFavoritesFive.Click += new System.EventHandler(this.btnMenuFavoritesFive_Click);
            // 
            // btnMenuFavoritesFour
            // 
            this.btnMenuFavoritesFour.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Halo_Halo;
            this.btnMenuFavoritesFour.Location = new System.Drawing.Point(1023, 22);
            this.btnMenuFavoritesFour.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuFavoritesFour.Name = "btnMenuFavoritesFour";
            this.btnMenuFavoritesFour.Size = new System.Drawing.Size(267, 190);
            this.btnMenuFavoritesFour.TabIndex = 26;
            this.btnMenuFavoritesFour.UseSelectable = true;
            this.btnMenuFavoritesFour.Click += new System.EventHandler(this.btnMenuFavoritesFour_Click);
            // 
            // btnMenuFavoritesThree
            // 
            this.btnMenuFavoritesThree.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Bacon___Cheese_Waffle;
            this.btnMenuFavoritesThree.Location = new System.Drawing.Point(689, 22);
            this.btnMenuFavoritesThree.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuFavoritesThree.Name = "btnMenuFavoritesThree";
            this.btnMenuFavoritesThree.Size = new System.Drawing.Size(267, 190);
            this.btnMenuFavoritesThree.TabIndex = 25;
            this.btnMenuFavoritesThree.UseSelectable = true;
            this.btnMenuFavoritesThree.Click += new System.EventHandler(this.btnMenuFavoritesThree_Click);
            // 
            // btnMenuFavoritesTwo
            // 
            this.btnMenuFavoritesTwo.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Cheese_Hotdog;
            this.btnMenuFavoritesTwo.Location = new System.Drawing.Point(355, 22);
            this.btnMenuFavoritesTwo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuFavoritesTwo.Name = "btnMenuFavoritesTwo";
            this.btnMenuFavoritesTwo.Size = new System.Drawing.Size(267, 190);
            this.btnMenuFavoritesTwo.TabIndex = 24;
            this.btnMenuFavoritesTwo.UseSelectable = true;
            this.btnMenuFavoritesTwo.Click += new System.EventHandler(this.btnMenuFavoritesTwo_Click);
            // 
            // btnMenuFavoritesOne
            // 
            this.btnMenuFavoritesOne.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Chicken_Sandwich;
            this.btnMenuFavoritesOne.Location = new System.Drawing.Point(20, 22);
            this.btnMenuFavoritesOne.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuFavoritesOne.Name = "btnMenuFavoritesOne";
            this.btnMenuFavoritesOne.Size = new System.Drawing.Size(267, 190);
            this.btnMenuFavoritesOne.TabIndex = 23;
            this.btnMenuFavoritesOne.UseSelectable = true;
            this.btnMenuFavoritesOne.Click += new System.EventHandler(this.btnMenuFavoritesOne_Click);
            // 
            // btnMenuDrinks
            // 
            this.btnMenuDrinks.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Background;
            this.btnMenuDrinks.Location = new System.Drawing.Point(373, 596);
            this.btnMenuDrinks.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinks.Name = "btnMenuDrinks";
            this.btnMenuDrinks.Size = new System.Drawing.Size(223, 63);
            this.btnMenuDrinks.TabIndex = 2;
            this.btnMenuDrinks.Text = "Drinks";
            this.btnMenuDrinks.UseSelectable = true;
            this.btnMenuDrinks.Click += new System.EventHandler(this.btnMenuDrinks_Click);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(1325, 313);
            this.metroLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(40, 20);
            this.metroLabel4.TabIndex = 6;
            this.metroLabel4.Text = "Total:";
            // 
            // btnMenuFavorites
            // 
            this.btnMenuFavorites.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Background;
            this.btnMenuFavorites.Location = new System.Drawing.Point(1044, 596);
            this.btnMenuFavorites.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuFavorites.Name = "btnMenuFavorites";
            this.btnMenuFavorites.Size = new System.Drawing.Size(223, 63);
            this.btnMenuFavorites.TabIndex = 4;
            this.btnMenuFavorites.Text = "Favorites";
            this.btnMenuFavorites.UseSelectable = true;
            this.btnMenuFavorites.Click += new System.EventHandler(this.btnMenuFavorites_Click);
            // 
            // btnMenuDessert
            // 
            this.btnMenuDessert.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Background;
            this.btnMenuDessert.Location = new System.Drawing.Point(712, 596);
            this.btnMenuDessert.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDessert.Name = "btnMenuDessert";
            this.btnMenuDessert.Size = new System.Drawing.Size(223, 63);
            this.btnMenuDessert.TabIndex = 3;
            this.btnMenuDessert.Text = "Dessert";
            this.btnMenuDessert.UseSelectable = true;
            this.btnMenuDessert.Click += new System.EventHandler(this.btnMenuDessert_Click);
            // 
            // txtMenuTotal
            // 
            // 
            // 
            // 
            this.txtMenuTotal.CustomButton.Image = null;
            this.txtMenuTotal.CustomButton.Location = new System.Drawing.Point(116, 2);
            this.txtMenuTotal.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtMenuTotal.CustomButton.Name = "";
            this.txtMenuTotal.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.txtMenuTotal.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtMenuTotal.CustomButton.TabIndex = 1;
            this.txtMenuTotal.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtMenuTotal.CustomButton.UseSelectable = true;
            this.txtMenuTotal.CustomButton.Visible = false;
            this.txtMenuTotal.Lines = new string[0];
            this.txtMenuTotal.Location = new System.Drawing.Point(1411, 308);
            this.txtMenuTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMenuTotal.MaxLength = 32767;
            this.txtMenuTotal.Name = "txtMenuTotal";
            this.txtMenuTotal.PasswordChar = '\0';
            this.txtMenuTotal.ReadOnly = true;
            this.txtMenuTotal.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMenuTotal.SelectedText = "";
            this.txtMenuTotal.SelectionLength = 0;
            this.txtMenuTotal.SelectionStart = 0;
            this.txtMenuTotal.ShortcutsEnabled = true;
            this.txtMenuTotal.Size = new System.Drawing.Size(113, 28);
            this.txtMenuTotal.TabIndex = 5;
            this.txtMenuTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtMenuTotal.UseSelectable = true;
            this.txtMenuTotal.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtMenuTotal.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnMenuMainCourse
            // 
            this.btnMenuMainCourse.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Background;
            this.btnMenuMainCourse.Location = new System.Drawing.Point(43, 596);
            this.btnMenuMainCourse.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourse.Name = "btnMenuMainCourse";
            this.btnMenuMainCourse.Size = new System.Drawing.Size(223, 63);
            this.btnMenuMainCourse.TabIndex = 1;
            this.btnMenuMainCourse.Text = "Main Course";
            this.btnMenuMainCourse.UseSelectable = true;
            this.btnMenuMainCourse.Click += new System.EventHandler(this.btnMenuMainCourse_Click);
            // 
            // txtMenuOrder
            // 
            // 
            // 
            // 
            this.txtMenuOrder.CustomButton.Image = null;
            this.txtMenuOrder.CustomButton.Location = new System.Drawing.Point(73, 1);
            this.txtMenuOrder.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtMenuOrder.CustomButton.Name = "";
            this.txtMenuOrder.CustomButton.Size = new System.Drawing.Size(260, 240);
            this.txtMenuOrder.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtMenuOrder.CustomButton.TabIndex = 1;
            this.txtMenuOrder.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtMenuOrder.CustomButton.UseSelectable = true;
            this.txtMenuOrder.CustomButton.Visible = false;
            this.txtMenuOrder.Lines = new string[0];
            this.txtMenuOrder.Location = new System.Drawing.Point(1412, 18);
            this.txtMenuOrder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMenuOrder.MaxLength = 32767;
            this.txtMenuOrder.Name = "txtMenuOrder";
            this.txtMenuOrder.PasswordChar = '\0';
            this.txtMenuOrder.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMenuOrder.SelectedText = "";
            this.txtMenuOrder.SelectionLength = 0;
            this.txtMenuOrder.SelectionStart = 0;
            this.txtMenuOrder.ShortcutsEnabled = true;
            this.txtMenuOrder.Size = new System.Drawing.Size(251, 197);
            this.txtMenuOrder.TabIndex = 3;
            this.txtMenuOrder.UseSelectable = true;
            this.txtMenuOrder.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtMenuOrder.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnMenuCheckOut
            // 
            this.btnMenuCheckOut.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Background;
            this.btnMenuCheckOut.Location = new System.Drawing.Point(1412, 368);
            this.btnMenuCheckOut.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuCheckOut.Name = "btnMenuCheckOut";
            this.btnMenuCheckOut.Size = new System.Drawing.Size(241, 65);
            this.btnMenuCheckOut.TabIndex = 4;
            this.btnMenuCheckOut.Text = "Check Out";
            this.btnMenuCheckOut.UseSelectable = true;
            this.btnMenuCheckOut.Click += new System.EventHandler(this.btnMenuCheckOut_Click);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(1327, 18);
            this.metroLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(60, 20);
            this.metroLabel3.TabIndex = 2;
            this.metroLabel3.Text = "Order/s:";
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.btnSalesRefund);
            this.metroTabPage2.Controls.Add(this.dataSalesFood);
            this.metroTabPage2.Controls.Add(this.dataSalesCustomer);
            this.metroTabPage2.Controls.Add(this.btnSalesSearch);
            this.metroTabPage2.Controls.Add(this.txtSaleSearch);
            this.metroTabPage2.Controls.Add(this.dataSales);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 12;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 41);
            this.metroTabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(1683, 717);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "Sales";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 13;
            // 
            // btnSalesRefund
            // 
            this.btnSalesRefund.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Background;
            this.btnSalesRefund.Location = new System.Drawing.Point(4, 4);
            this.btnSalesRefund.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSalesRefund.Name = "btnSalesRefund";
            this.btnSalesRefund.Size = new System.Drawing.Size(179, 28);
            this.btnSalesRefund.TabIndex = 9;
            this.btnSalesRefund.Text = "REFUND ORDER";
            this.btnSalesRefund.UseSelectable = true;
            this.btnSalesRefund.Click += new System.EventHandler(this.btnSalesRefund_Click);
            // 
            // dataSalesFood
            // 
            this.dataSalesFood.AllowUserToAddRows = false;
            this.dataSalesFood.AllowUserToDeleteRows = false;
            this.dataSalesFood.AllowUserToResizeRows = false;
            this.dataSalesFood.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataSalesFood.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataSalesFood.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataSalesFood.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSalesFood.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataSalesFood.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataSalesFood.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.food_ID,
            this.food_Name,
            this.food_Type,
            this.food_Price});
            this.dataSalesFood.Cursor = System.Windows.Forms.Cursors.No;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataSalesFood.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataSalesFood.EnableHeadersVisualStyles = false;
            this.dataSalesFood.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataSalesFood.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataSalesFood.Location = new System.Drawing.Point(892, 37);
            this.dataSalesFood.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataSalesFood.Name = "dataSalesFood";
            this.dataSalesFood.ReadOnly = true;
            this.dataSalesFood.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSalesFood.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataSalesFood.RowHeadersWidth = 51;
            this.dataSalesFood.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataSalesFood.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataSalesFood.Size = new System.Drawing.Size(760, 332);
            this.dataSalesFood.Style = MetroFramework.MetroColorStyle.Orange;
            this.dataSalesFood.TabIndex = 8;
            // 
            // food_ID
            // 
            this.food_ID.HeaderText = "FOOD ID";
            this.food_ID.MinimumWidth = 6;
            this.food_ID.Name = "food_ID";
            this.food_ID.ReadOnly = true;
            this.food_ID.Width = 125;
            // 
            // food_Name
            // 
            this.food_Name.HeaderText = "FOOD NAME";
            this.food_Name.MinimumWidth = 6;
            this.food_Name.Name = "food_Name";
            this.food_Name.ReadOnly = true;
            this.food_Name.Width = 125;
            // 
            // food_Type
            // 
            this.food_Type.HeaderText = "FOOD TYPE";
            this.food_Type.MinimumWidth = 6;
            this.food_Type.Name = "food_Type";
            this.food_Type.ReadOnly = true;
            this.food_Type.Width = 125;
            // 
            // food_Price
            // 
            this.food_Price.HeaderText = "FOOD PRICE";
            this.food_Price.MinimumWidth = 6;
            this.food_Price.Name = "food_Price";
            this.food_Price.ReadOnly = true;
            this.food_Price.Width = 125;
            // 
            // dataSalesCustomer
            // 
            this.dataSalesCustomer.AllowUserToAddRows = false;
            this.dataSalesCustomer.AllowUserToDeleteRows = false;
            this.dataSalesCustomer.AllowUserToResizeRows = false;
            this.dataSalesCustomer.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataSalesCustomer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataSalesCustomer.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataSalesCustomer.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSalesCustomer.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataSalesCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataSalesCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.customer_ID,
            this.customer_Date});
            this.dataSalesCustomer.Cursor = System.Windows.Forms.Cursors.No;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataSalesCustomer.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataSalesCustomer.EnableHeadersVisualStyles = false;
            this.dataSalesCustomer.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataSalesCustomer.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataSalesCustomer.Location = new System.Drawing.Point(892, 389);
            this.dataSalesCustomer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataSalesCustomer.Name = "dataSalesCustomer";
            this.dataSalesCustomer.ReadOnly = true;
            this.dataSalesCustomer.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSalesCustomer.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataSalesCustomer.RowHeadersWidth = 51;
            this.dataSalesCustomer.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataSalesCustomer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataSalesCustomer.Size = new System.Drawing.Size(475, 332);
            this.dataSalesCustomer.Style = MetroFramework.MetroColorStyle.Orange;
            this.dataSalesCustomer.TabIndex = 7;
            // 
            // customer_ID
            // 
            this.customer_ID.HeaderText = "CUSTOMER ID";
            this.customer_ID.MinimumWidth = 6;
            this.customer_ID.Name = "customer_ID";
            this.customer_ID.ReadOnly = true;
            this.customer_ID.Width = 125;
            // 
            // customer_Date
            // 
            this.customer_Date.HeaderText = "DATE";
            this.customer_Date.MinimumWidth = 6;
            this.customer_Date.Name = "customer_Date";
            this.customer_Date.ReadOnly = true;
            this.customer_Date.Width = 125;
            // 
            // btnSalesSearch
            // 
            this.btnSalesSearch.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Background;
            this.btnSalesSearch.Location = new System.Drawing.Point(191, 4);
            this.btnSalesSearch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSalesSearch.Name = "btnSalesSearch";
            this.btnSalesSearch.Size = new System.Drawing.Size(127, 28);
            this.btnSalesSearch.TabIndex = 6;
            this.btnSalesSearch.Text = "SEARCH";
            this.btnSalesSearch.UseSelectable = true;
            this.btnSalesSearch.Click += new System.EventHandler(this.btnSalesSearch_Click);
            // 
            // txtSaleSearch
            // 
            // 
            // 
            // 
            this.txtSaleSearch.CustomButton.Image = null;
            this.txtSaleSearch.CustomButton.Location = new System.Drawing.Point(1735, 2);
            this.txtSaleSearch.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtSaleSearch.CustomButton.Name = "";
            this.txtSaleSearch.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.txtSaleSearch.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSaleSearch.CustomButton.TabIndex = 1;
            this.txtSaleSearch.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSaleSearch.CustomButton.UseSelectable = true;
            this.txtSaleSearch.CustomButton.Visible = false;
            this.txtSaleSearch.Lines = new string[0];
            this.txtSaleSearch.Location = new System.Drawing.Point(325, 4);
            this.txtSaleSearch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSaleSearch.MaxLength = 32767;
            this.txtSaleSearch.Name = "txtSaleSearch";
            this.txtSaleSearch.PasswordChar = '\0';
            this.txtSaleSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSaleSearch.SelectedText = "";
            this.txtSaleSearch.SelectionLength = 0;
            this.txtSaleSearch.SelectionStart = 0;
            this.txtSaleSearch.ShortcutsEnabled = true;
            this.txtSaleSearch.Size = new System.Drawing.Size(1327, 28);
            this.txtSaleSearch.TabIndex = 5;
            this.txtSaleSearch.UseSelectable = true;
            this.txtSaleSearch.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSaleSearch.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // dataSales
            // 
            this.dataSales.AllowUserToAddRows = false;
            this.dataSales.AllowUserToDeleteRows = false;
            this.dataSales.AllowUserToResizeRows = false;
            this.dataSales.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataSales.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataSales.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataSales.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSales.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataSales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataSales.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sales_ID,
            this.sales_customerID,
            this.sales_FoodName,
            this.sales_Quantity,
            this.sales_Date,
            this.sales_TotalPrice});
            this.dataSales.Cursor = System.Windows.Forms.Cursors.No;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataSales.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataSales.EnableHeadersVisualStyles = false;
            this.dataSales.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataSales.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataSales.Location = new System.Drawing.Point(-4, 37);
            this.dataSales.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataSales.Name = "dataSales";
            this.dataSales.ReadOnly = true;
            this.dataSales.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSales.RowHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dataSales.RowHeadersWidth = 51;
            this.dataSales.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataSales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataSales.Size = new System.Drawing.Size(869, 684);
            this.dataSales.Style = MetroFramework.MetroColorStyle.Orange;
            this.dataSales.TabIndex = 4;
            // 
            // sales_ID
            // 
            this.sales_ID.HeaderText = "SALES ID";
            this.sales_ID.MinimumWidth = 6;
            this.sales_ID.Name = "sales_ID";
            this.sales_ID.ReadOnly = true;
            this.sales_ID.Width = 80;
            // 
            // sales_customerID
            // 
            this.sales_customerID.DataPropertyName = "cust_ID";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.sales_customerID.DefaultCellStyle = dataGridViewCellStyle8;
            this.sales_customerID.HeaderText = "CUSTOMER ID";
            this.sales_customerID.MinimumWidth = 6;
            this.sales_customerID.Name = "sales_customerID";
            this.sales_customerID.ReadOnly = true;
            this.sales_customerID.Width = 80;
            // 
            // sales_FoodName
            // 
            this.sales_FoodName.HeaderText = "FOOD NAME";
            this.sales_FoodName.MinimumWidth = 6;
            this.sales_FoodName.Name = "sales_FoodName";
            this.sales_FoodName.ReadOnly = true;
            this.sales_FoodName.Width = 110;
            // 
            // sales_Quantity
            // 
            this.sales_Quantity.DataPropertyName = "sales_Quantity";
            this.sales_Quantity.HeaderText = "QUANTITY";
            this.sales_Quantity.MinimumWidth = 6;
            this.sales_Quantity.Name = "sales_Quantity";
            this.sales_Quantity.ReadOnly = true;
            this.sales_Quantity.Width = 80;
            // 
            // sales_Date
            // 
            this.sales_Date.HeaderText = "DATE";
            this.sales_Date.MinimumWidth = 6;
            this.sales_Date.Name = "sales_Date";
            this.sales_Date.ReadOnly = true;
            this.sales_Date.Width = 125;
            // 
            // sales_TotalPrice
            // 
            this.sales_TotalPrice.HeaderText = "TOTAL PRICE";
            this.sales_TotalPrice.MinimumWidth = 6;
            this.sales_TotalPrice.Name = "sales_TotalPrice";
            this.sales_TotalPrice.ReadOnly = true;
            this.sales_TotalPrice.Width = 95;
            // 
            // metroDateTime1
            // 
            this.metroDateTime1.CausesValidation = false;
            this.metroDateTime1.Checked = false;
            this.metroDateTime1.Location = new System.Drawing.Point(1449, 52);
            this.metroDateTime1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroDateTime1.MinimumSize = new System.Drawing.Size(0, 30);
            this.metroDateTime1.Name = "metroDateTime1";
            this.metroDateTime1.Size = new System.Drawing.Size(265, 30);
            this.metroDateTime1.TabIndex = 1;
            this.metroDateTime1.TabStop = false;
            // 
            // frmHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackImage = global::Group1_Eats2Go.Properties.Resources.Background;
            this.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(1756, 895);
            this.Controls.Add(this.metroDateTime1);
            this.Controls.Add(this.metroTabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmHome";
            this.Padding = new System.Windows.Forms.Padding(27, 74, 27, 25);
            this.Style = MetroFramework.MetroColorStyle.Orange;
            this.Text = "Eats2Go";
            this.Load += new System.EventHandler(this.frmHome_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            this.tabMenuControl.ResumeLayout(false);
            this.tabMainCoursePage.ResumeLayout(false);
            this.tabDrinksPage.ResumeLayout(false);
            this.tabDessertPage.ResumeLayout(false);
            this.tabFavoritesPage.ResumeLayout(false);
            this.metroTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataSalesFood)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSalesCustomer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSales)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroGrid dataSales;
        private MetroFramework.Controls.MetroButton btnSalesSearch;
        private MetroFramework.Controls.MetroTextBox txtSaleSearch;
        private MetroFramework.Controls.MetroDateTime metroDateTime1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTabControl tabMenuControl;
        private MetroFramework.Controls.MetroTabPage tabMainCoursePage;
        private MetroFramework.Controls.MetroTabPage tabDrinksPage;
        private MetroFramework.Controls.MetroTabPage tabDessertPage;
        private MetroFramework.Controls.MetroTabPage tabFavoritesPage;
        private MetroFramework.Controls.MetroButton btnMenuFavorites;
        private MetroFramework.Controls.MetroButton btnMenuDessert;
        private MetroFramework.Controls.MetroButton btnMenuMainCourse;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseFour;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseThree;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseTwo;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseOne;
        private MetroFramework.Controls.MetroButton btnMenuDrinksSeven;
        private MetroFramework.Controls.MetroButton btnMenuDrinksFive;
        private MetroFramework.Controls.MetroButton btnMenuDrinksFour;
        private MetroFramework.Controls.MetroButton btnMenuDrinksThree;
        private MetroFramework.Controls.MetroButton btnMenuDrinksTwo;
        private MetroFramework.Controls.MetroButton btnMenuDrinksOne;
        private MetroFramework.Controls.MetroButton btnMenuDessertFour;
        private MetroFramework.Controls.MetroButton btnMenuDessertThree;
        private MetroFramework.Controls.MetroButton btnMenuDessertTwo;
        private MetroFramework.Controls.MetroButton btnMenuDessertOne;
        private MetroFramework.Controls.MetroButton btnMenuFavoritesFive;
        private MetroFramework.Controls.MetroButton btnMenuFavoritesFour;
        private MetroFramework.Controls.MetroButton btnMenuFavoritesThree;
        private MetroFramework.Controls.MetroButton btnMenuFavoritesTwo;
        private MetroFramework.Controls.MetroButton btnMenuFavoritesOne;
        private MetroFramework.Controls.MetroButton btnMenuDrinks;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseEight;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseSeven;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseSix;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseFive;
        private MetroFramework.Controls.MetroGrid dataSalesFood;
        private MetroFramework.Controls.MetroGrid dataSalesCustomer;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox txtMenuOrder;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroTextBox txtMenuTotal;
        private MetroFramework.Controls.MetroButton btnMenuCheckOut;
        private MetroFramework.Controls.MetroButton btnMenuCancel;
        private System.Windows.Forms.DataGridViewTextBoxColumn food_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn food_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn food_Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn food_Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn sales_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn sales_customerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn sales_FoodName;
        private System.Windows.Forms.DataGridViewTextBoxColumn sales_Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn sales_Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn sales_TotalPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn customer_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn customer_Date;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroTextBox metroTextBox4;
        private MetroFramework.Controls.MetroTextBox metroTextBox6;
        private MetroFramework.Controls.MetroTextBox metroTextBox7;
        private MetroFramework.Controls.MetroTextBox metroTextBox8;
        private MetroFramework.Controls.MetroTextBox metroTextBox9;
        private MetroFramework.Controls.MetroTextBox metroTextBox2;
        private MetroFramework.Controls.MetroTextBox metroTextBox5;
        private MetroFramework.Controls.MetroTextBox metroTextBox3;
        private MetroFramework.Controls.MetroTextBox metroTextBox14;
        private MetroFramework.Controls.MetroTextBox metroTextBox15;
        private MetroFramework.Controls.MetroTextBox metroTextBox10;
        private MetroFramework.Controls.MetroTextBox metroTextBox11;
        private MetroFramework.Controls.MetroTextBox metroTextBox12;
        private MetroFramework.Controls.MetroTextBox metroTextBox13;
        private MetroFramework.Controls.MetroTextBox metroTextBox16;
        private MetroFramework.Controls.MetroTextBox metroTextBox17;
        private MetroFramework.Controls.MetroTextBox metroTextBox18;
        private MetroFramework.Controls.MetroTextBox metroTextBox19;
        private MetroFramework.Controls.MetroTextBox metroTextBox24;
        private MetroFramework.Controls.MetroTextBox metroTextBox20;
        private MetroFramework.Controls.MetroTextBox metroTextBox21;
        private MetroFramework.Controls.MetroTextBox metroTextBox22;
        private MetroFramework.Controls.MetroTextBox metroTextBox23;
        private MetroFramework.Controls.MetroButton btnSalesRefund;
    }
}

