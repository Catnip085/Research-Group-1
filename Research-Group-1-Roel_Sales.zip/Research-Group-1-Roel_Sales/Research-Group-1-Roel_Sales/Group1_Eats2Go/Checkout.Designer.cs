﻿namespace Group1_Eats2Go
{
    partial class frmCheckout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCheckout));
            this.chckCancelbtn = new MetroFramework.Controls.MetroButton();
            this.Card_Confirmbtn = new MetroFramework.Controls.MetroButton();
            this.txtTotalChk = new System.Windows.Forms.TextBox();
            this.txtMenuOrderchk = new MetroFramework.Controls.MetroTextBox();
            this.CashConfirm = new MetroFramework.Controls.MetroButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // chckCancelbtn
            // 
            this.chckCancelbtn.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Background;
            this.chckCancelbtn.Location = new System.Drawing.Point(644, 386);
            this.chckCancelbtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chckCancelbtn.Name = "chckCancelbtn";
            this.chckCancelbtn.Size = new System.Drawing.Size(249, 90);
            this.chckCancelbtn.TabIndex = 33;
            this.chckCancelbtn.Text = "CANCEL";
            this.chckCancelbtn.UseSelectable = true;
            this.chckCancelbtn.Click += new System.EventHandler(this.chckCancelbtn_Click);
            // 
            // Card_Confirmbtn
            // 
            this.Card_Confirmbtn.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Background;
            this.Card_Confirmbtn.Location = new System.Drawing.Point(340, 386);
            this.Card_Confirmbtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Card_Confirmbtn.Name = "Card_Confirmbtn";
            this.Card_Confirmbtn.Size = new System.Drawing.Size(249, 90);
            this.Card_Confirmbtn.TabIndex = 32;
            this.Card_Confirmbtn.Text = "PAY WITH CARD";
            this.Card_Confirmbtn.UseSelectable = true;
            this.Card_Confirmbtn.Click += new System.EventHandler(this.Card_Confirmbtn_Click);
            // 
            // txtTotalChk
            // 
            this.txtTotalChk.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalChk.Location = new System.Drawing.Point(644, 133);
            this.txtTotalChk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTotalChk.Multiline = true;
            this.txtTotalChk.Name = "txtTotalChk";
            this.txtTotalChk.ReadOnly = true;
            this.txtTotalChk.Size = new System.Drawing.Size(249, 94);
            this.txtTotalChk.TabIndex = 31;
            // 
            // txtMenuOrderchk
            // 
            // 
            // 
            // 
            this.txtMenuOrderchk.CustomButton.Image = null;
            this.txtMenuOrderchk.CustomButton.Location = new System.Drawing.Point(369, 1);
            this.txtMenuOrderchk.CustomButton.Margin = new System.Windows.Forms.Padding(5);
            this.txtMenuOrderchk.CustomButton.Name = "";
            this.txtMenuOrderchk.CustomButton.Size = new System.Drawing.Size(183, 183);
            this.txtMenuOrderchk.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtMenuOrderchk.CustomButton.TabIndex = 1;
            this.txtMenuOrderchk.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtMenuOrderchk.CustomButton.UseSelectable = true;
            this.txtMenuOrderchk.CustomButton.Visible = false;
            this.txtMenuOrderchk.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtMenuOrderchk.FontWeight = MetroFramework.MetroTextBoxWeight.Bold;
            this.txtMenuOrderchk.Lines = new string[0];
            this.txtMenuOrderchk.Location = new System.Drawing.Point(36, 133);
            this.txtMenuOrderchk.Margin = new System.Windows.Forms.Padding(4);
            this.txtMenuOrderchk.MaxLength = 32767;
            this.txtMenuOrderchk.Multiline = true;
            this.txtMenuOrderchk.Name = "txtMenuOrderchk";
            this.txtMenuOrderchk.PasswordChar = '\0';
            this.txtMenuOrderchk.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMenuOrderchk.SelectedText = "";
            this.txtMenuOrderchk.SelectionLength = 0;
            this.txtMenuOrderchk.SelectionStart = 0;
            this.txtMenuOrderchk.ShortcutsEnabled = true;
            this.txtMenuOrderchk.Size = new System.Drawing.Size(553, 185);
            this.txtMenuOrderchk.TabIndex = 30;
            this.txtMenuOrderchk.UseSelectable = true;
            this.txtMenuOrderchk.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtMenuOrderchk.WaterMarkFont = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // CashConfirm
            // 
            this.CashConfirm.BackgroundImage = global::Group1_Eats2Go.Properties.Resources.Background;
            this.CashConfirm.Location = new System.Drawing.Point(36, 386);
            this.CashConfirm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CashConfirm.Name = "CashConfirm";
            this.CashConfirm.Size = new System.Drawing.Size(249, 90);
            this.CashConfirm.TabIndex = 29;
            this.CashConfirm.Text = "PAY WITH CASH";
            this.CashConfirm.UseSelectable = true;
            this.CashConfirm.Click += new System.EventHandler(this.CashConfirm_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(639, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 25);
            this.label1.TabIndex = 28;
            this.label1.Text = "ESTIMATED TOTAL:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(31, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 25);
            this.label2.TabIndex = 27;
            this.label2.Text = "ORDER DETAILS:";
            // 
            // frmCheckout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(953, 554);
            this.Controls.Add(this.chckCancelbtn);
            this.Controls.Add(this.Card_Confirmbtn);
            this.Controls.Add(this.txtTotalChk);
            this.Controls.Add(this.txtMenuOrderchk);
            this.Controls.Add(this.CashConfirm);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmCheckout";
            this.Padding = new System.Windows.Forms.Padding(27, 74, 27, 25);
            this.Style = MetroFramework.MetroColorStyle.Orange;
            this.Text = "Checkout";
            this.Load += new System.EventHandler(this.frmCheckout_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton chckCancelbtn;
        private MetroFramework.Controls.MetroButton Card_Confirmbtn;
        private System.Windows.Forms.TextBox txtTotalChk;
        private MetroFramework.Controls.MetroTextBox txtMenuOrderchk;
        private MetroFramework.Controls.MetroButton CashConfirm;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}