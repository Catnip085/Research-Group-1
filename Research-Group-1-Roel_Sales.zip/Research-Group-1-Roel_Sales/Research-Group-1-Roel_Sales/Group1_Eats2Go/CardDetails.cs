﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using MetroFramework.Forms;

namespace Group1_Eats2Go
{
    public partial class CardDetails : MetroForm
    {
        private frmCheckout _formcheck;
        public CardDetails(frmCheckout formCheckout)
        {
            InitializeComponent();

            _formcheck = formCheckout;
        }

        private void CardDetails_Load(object sender, EventArgs e)
        {

        }

        private void okbutton_Click(object sender, EventArgs e)
        {
            if (cardnumtxtdtl.Text.Length != 16)
            {
                MessageBox.Show("Please enter exactly 16 digits.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {

                this.Show(); MessageBox.Show("Paid with CARD!", "Checkout", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
                _formcheck.InsertOrdersToDatabase();
                _formcheck.Close();
            }
        }

        private void cardnumtxtdtl_TextChanged(object sender, EventArgs e)
        {
            string input = cardnumtxtdtl.Text;
            if (!input.All(char.IsDigit))
            {
                MessageBox.Show("Only numeric values are allowed.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cardnumtxtdtl.Text = string.Concat(input.Where(char.IsDigit));
                cardnumtxtdtl.SelectionStart = cardnumtxtdtl.Text.Length;
            }
        }
    }
}
